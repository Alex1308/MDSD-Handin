package org.xtext.mdsd.guipro.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.mdsd.guipro.services.GuiProGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGuiProParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'frame.vertical'", "'frame.horizontal'", "'{'", "'}'", "'panel.vertical'", "'panel.horizontal'", "'button'", "'textField'", "'checkBox'", "'label'", "'listView'", "'('", "','", "')'", "':'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=5;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalGuiProParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGuiProParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGuiProParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGuiPro.g"; }



     	private GuiProGrammarAccess grammarAccess;

        public InternalGuiProParser(TokenStream input, GuiProGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "System";
       	}

       	@Override
       	protected GuiProGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSystem"
    // InternalGuiPro.g:64:1: entryRuleSystem returns [EObject current=null] : iv_ruleSystem= ruleSystem EOF ;
    public final EObject entryRuleSystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSystem = null;


        try {
            // InternalGuiPro.g:64:47: (iv_ruleSystem= ruleSystem EOF )
            // InternalGuiPro.g:65:2: iv_ruleSystem= ruleSystem EOF
            {
             newCompositeNode(grammarAccess.getSystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSystem=ruleSystem();

            state._fsp--;

             current =iv_ruleSystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSystem"


    // $ANTLR start "ruleSystem"
    // InternalGuiPro.g:71:1: ruleSystem returns [EObject current=null] : ( (lv_frames_0_0= ruleFrame ) ) ;
    public final EObject ruleSystem() throws RecognitionException {
        EObject current = null;

        EObject lv_frames_0_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:77:2: ( ( (lv_frames_0_0= ruleFrame ) ) )
            // InternalGuiPro.g:78:2: ( (lv_frames_0_0= ruleFrame ) )
            {
            // InternalGuiPro.g:78:2: ( (lv_frames_0_0= ruleFrame ) )
            // InternalGuiPro.g:79:3: (lv_frames_0_0= ruleFrame )
            {
            // InternalGuiPro.g:79:3: (lv_frames_0_0= ruleFrame )
            // InternalGuiPro.g:80:4: lv_frames_0_0= ruleFrame
            {

            				newCompositeNode(grammarAccess.getSystemAccess().getFramesFrameParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_frames_0_0=ruleFrame();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getSystemRule());
            				}
            				add(
            					current,
            					"frames",
            					lv_frames_0_0,
            					"org.xtext.mdsd.guipro.GuiPro.Frame");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSystem"


    // $ANTLR start "entryRuleFrame"
    // InternalGuiPro.g:100:1: entryRuleFrame returns [EObject current=null] : iv_ruleFrame= ruleFrame EOF ;
    public final EObject entryRuleFrame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFrame = null;


        try {
            // InternalGuiPro.g:100:46: (iv_ruleFrame= ruleFrame EOF )
            // InternalGuiPro.g:101:2: iv_ruleFrame= ruleFrame EOF
            {
             newCompositeNode(grammarAccess.getFrameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFrame=ruleFrame();

            state._fsp--;

             current =iv_ruleFrame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFrame"


    // $ANTLR start "ruleFrame"
    // InternalGuiPro.g:107:1: ruleFrame returns [EObject current=null] : ( ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? otherlv_4= '{' ( (lv_panels_5_0= rulePanel ) )* otherlv_6= '}' ) ;
    public final EObject ruleFrame() throws RecognitionException {
        EObject current = null;

        Token lv_left_0_1=null;
        Token lv_left_0_2=null;
        Token lv_name_1_0=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_center_2_0 = null;

        EObject lv_right_3_0 = null;

        EObject lv_panels_5_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:113:2: ( ( ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? otherlv_4= '{' ( (lv_panels_5_0= rulePanel ) )* otherlv_6= '}' ) )
            // InternalGuiPro.g:114:2: ( ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? otherlv_4= '{' ( (lv_panels_5_0= rulePanel ) )* otherlv_6= '}' )
            {
            // InternalGuiPro.g:114:2: ( ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? otherlv_4= '{' ( (lv_panels_5_0= rulePanel ) )* otherlv_6= '}' )
            // InternalGuiPro.g:115:3: ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? otherlv_4= '{' ( (lv_panels_5_0= rulePanel ) )* otherlv_6= '}'
            {
            // InternalGuiPro.g:115:3: ( ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) ) )
            // InternalGuiPro.g:116:4: ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) )
            {
            // InternalGuiPro.g:116:4: ( (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' ) )
            // InternalGuiPro.g:117:5: (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' )
            {
            // InternalGuiPro.g:117:5: (lv_left_0_1= 'frame.vertical' | lv_left_0_2= 'frame.horizontal' )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            else if ( (LA1_0==12) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalGuiPro.g:118:6: lv_left_0_1= 'frame.vertical'
                    {
                    lv_left_0_1=(Token)match(input,11,FOLLOW_3); 

                    						newLeafNode(lv_left_0_1, grammarAccess.getFrameAccess().getLeftFrameVerticalKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFrameRule());
                    						}
                    						setWithLastConsumed(current, "left", lv_left_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:129:6: lv_left_0_2= 'frame.horizontal'
                    {
                    lv_left_0_2=(Token)match(input,12,FOLLOW_3); 

                    						newLeafNode(lv_left_0_2, grammarAccess.getFrameAccess().getLeftFrameHorizontalKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFrameRule());
                    						}
                    						setWithLastConsumed(current, "left", lv_left_0_2, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalGuiPro.g:142:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:143:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:143:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:144:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getFrameAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFrameRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:160:3: ( (lv_center_2_0= ruleText ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==25) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalGuiPro.g:161:4: (lv_center_2_0= ruleText )
                    {
                    // InternalGuiPro.g:161:4: (lv_center_2_0= ruleText )
                    // InternalGuiPro.g:162:5: lv_center_2_0= ruleText
                    {

                    					newCompositeNode(grammarAccess.getFrameAccess().getCenterTextParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_5);
                    lv_center_2_0=ruleText();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getFrameRule());
                    					}
                    					set(
                    						current,
                    						"center",
                    						lv_center_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Text");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGuiPro.g:179:3: ( (lv_right_3_0= ruleSize ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==22) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalGuiPro.g:180:4: (lv_right_3_0= ruleSize )
                    {
                    // InternalGuiPro.g:180:4: (lv_right_3_0= ruleSize )
                    // InternalGuiPro.g:181:5: lv_right_3_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getFrameAccess().getRightSizeParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_right_3_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getFrameRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_3_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,13,FOLLOW_7); 

            			newLeafNode(otherlv_4, grammarAccess.getFrameAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalGuiPro.g:202:3: ( (lv_panels_5_0= rulePanel ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=15 && LA4_0<=16)) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalGuiPro.g:203:4: (lv_panels_5_0= rulePanel )
            	    {
            	    // InternalGuiPro.g:203:4: (lv_panels_5_0= rulePanel )
            	    // InternalGuiPro.g:204:5: lv_panels_5_0= rulePanel
            	    {

            	    					newCompositeNode(grammarAccess.getFrameAccess().getPanelsPanelParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_panels_5_0=rulePanel();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFrameRule());
            	    					}
            	    					add(
            	    						current,
            	    						"panels",
            	    						lv_panels_5_0,
            	    						"org.xtext.mdsd.guipro.GuiPro.Panel");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_6=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getFrameAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFrame"


    // $ANTLR start "entryRulePanel"
    // InternalGuiPro.g:229:1: entryRulePanel returns [EObject current=null] : iv_rulePanel= rulePanel EOF ;
    public final EObject entryRulePanel() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePanel = null;


        try {
            // InternalGuiPro.g:229:46: (iv_rulePanel= rulePanel EOF )
            // InternalGuiPro.g:230:2: iv_rulePanel= rulePanel EOF
            {
             newCompositeNode(grammarAccess.getPanelRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePanel=rulePanel();

            state._fsp--;

             current =iv_rulePanel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePanel"


    // $ANTLR start "rulePanel"
    // InternalGuiPro.g:236:1: rulePanel returns [EObject current=null] : ( ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? otherlv_3= '{' ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )* otherlv_6= '}' ) ;
    public final EObject rulePanel() throws RecognitionException {
        EObject current = null;

        Token lv_left_0_1=null;
        Token lv_left_0_2=null;
        Token lv_name_1_0=null;
        Token otherlv_3=null;
        Token otherlv_6=null;
        EObject lv_right_2_0 = null;

        EObject lv_controls_4_0 = null;

        EObject lv_panels_5_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:242:2: ( ( ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? otherlv_3= '{' ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )* otherlv_6= '}' ) )
            // InternalGuiPro.g:243:2: ( ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? otherlv_3= '{' ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )* otherlv_6= '}' )
            {
            // InternalGuiPro.g:243:2: ( ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? otherlv_3= '{' ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )* otherlv_6= '}' )
            // InternalGuiPro.g:244:3: ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? otherlv_3= '{' ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )* otherlv_6= '}'
            {
            // InternalGuiPro.g:244:3: ( ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) ) )
            // InternalGuiPro.g:245:4: ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) )
            {
            // InternalGuiPro.g:245:4: ( (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' ) )
            // InternalGuiPro.g:246:5: (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' )
            {
            // InternalGuiPro.g:246:5: (lv_left_0_1= 'panel.vertical' | lv_left_0_2= 'panel.horizontal' )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==15) ) {
                alt5=1;
            }
            else if ( (LA5_0==16) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalGuiPro.g:247:6: lv_left_0_1= 'panel.vertical'
                    {
                    lv_left_0_1=(Token)match(input,15,FOLLOW_3); 

                    						newLeafNode(lv_left_0_1, grammarAccess.getPanelAccess().getLeftPanelVerticalKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPanelRule());
                    						}
                    						setWithLastConsumed(current, "left", lv_left_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:258:6: lv_left_0_2= 'panel.horizontal'
                    {
                    lv_left_0_2=(Token)match(input,16,FOLLOW_3); 

                    						newLeafNode(lv_left_0_2, grammarAccess.getPanelAccess().getLeftPanelHorizontalKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPanelRule());
                    						}
                    						setWithLastConsumed(current, "left", lv_left_0_2, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalGuiPro.g:271:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:272:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:272:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:273:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPanelAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPanelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:289:3: ( (lv_right_2_0= ruleSize ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==22) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalGuiPro.g:290:4: (lv_right_2_0= ruleSize )
                    {
                    // InternalGuiPro.g:290:4: (lv_right_2_0= ruleSize )
                    // InternalGuiPro.g:291:5: lv_right_2_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getPanelAccess().getRightSizeParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_right_2_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPanelRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_3=(Token)match(input,13,FOLLOW_8); 

            			newLeafNode(otherlv_3, grammarAccess.getPanelAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalGuiPro.g:312:3: ( ( (lv_controls_4_0= ruleControl ) ) | ( (lv_panels_5_0= rulePanel ) ) )*
            loop7:
            do {
                int alt7=3;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>=17 && LA7_0<=21)) ) {
                    alt7=1;
                }
                else if ( ((LA7_0>=15 && LA7_0<=16)) ) {
                    alt7=2;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalGuiPro.g:313:4: ( (lv_controls_4_0= ruleControl ) )
            	    {
            	    // InternalGuiPro.g:313:4: ( (lv_controls_4_0= ruleControl ) )
            	    // InternalGuiPro.g:314:5: (lv_controls_4_0= ruleControl )
            	    {
            	    // InternalGuiPro.g:314:5: (lv_controls_4_0= ruleControl )
            	    // InternalGuiPro.g:315:6: lv_controls_4_0= ruleControl
            	    {

            	    						newCompositeNode(grammarAccess.getPanelAccess().getControlsControlParserRuleCall_4_0_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_controls_4_0=ruleControl();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getPanelRule());
            	    						}
            	    						add(
            	    							current,
            	    							"controls",
            	    							lv_controls_4_0,
            	    							"org.xtext.mdsd.guipro.GuiPro.Control");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalGuiPro.g:333:4: ( (lv_panels_5_0= rulePanel ) )
            	    {
            	    // InternalGuiPro.g:333:4: ( (lv_panels_5_0= rulePanel ) )
            	    // InternalGuiPro.g:334:5: (lv_panels_5_0= rulePanel )
            	    {
            	    // InternalGuiPro.g:334:5: (lv_panels_5_0= rulePanel )
            	    // InternalGuiPro.g:335:6: lv_panels_5_0= rulePanel
            	    {

            	    						newCompositeNode(grammarAccess.getPanelAccess().getPanelsPanelParserRuleCall_4_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_panels_5_0=rulePanel();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getPanelRule());
            	    						}
            	    						add(
            	    							current,
            	    							"panels",
            	    							lv_panels_5_0,
            	    							"org.xtext.mdsd.guipro.GuiPro.Panel");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_6=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getPanelAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePanel"


    // $ANTLR start "entryRuleControl"
    // InternalGuiPro.g:361:1: entryRuleControl returns [EObject current=null] : iv_ruleControl= ruleControl EOF ;
    public final EObject entryRuleControl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleControl = null;


        try {
            // InternalGuiPro.g:361:48: (iv_ruleControl= ruleControl EOF )
            // InternalGuiPro.g:362:2: iv_ruleControl= ruleControl EOF
            {
             newCompositeNode(grammarAccess.getControlRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleControl=ruleControl();

            state._fsp--;

             current =iv_ruleControl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleControl"


    // $ANTLR start "ruleControl"
    // InternalGuiPro.g:368:1: ruleControl returns [EObject current=null] : (this_Button_0= ruleButton | this_TextField_1= ruleTextField | this_CheckBox_2= ruleCheckBox | this_Label_3= ruleLabel | this_ListView_4= ruleListView ) ;
    public final EObject ruleControl() throws RecognitionException {
        EObject current = null;

        EObject this_Button_0 = null;

        EObject this_TextField_1 = null;

        EObject this_CheckBox_2 = null;

        EObject this_Label_3 = null;

        EObject this_ListView_4 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:374:2: ( (this_Button_0= ruleButton | this_TextField_1= ruleTextField | this_CheckBox_2= ruleCheckBox | this_Label_3= ruleLabel | this_ListView_4= ruleListView ) )
            // InternalGuiPro.g:375:2: (this_Button_0= ruleButton | this_TextField_1= ruleTextField | this_CheckBox_2= ruleCheckBox | this_Label_3= ruleLabel | this_ListView_4= ruleListView )
            {
            // InternalGuiPro.g:375:2: (this_Button_0= ruleButton | this_TextField_1= ruleTextField | this_CheckBox_2= ruleCheckBox | this_Label_3= ruleLabel | this_ListView_4= ruleListView )
            int alt8=5;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt8=1;
                }
                break;
            case 18:
                {
                alt8=2;
                }
                break;
            case 19:
                {
                alt8=3;
                }
                break;
            case 20:
                {
                alt8=4;
                }
                break;
            case 21:
                {
                alt8=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalGuiPro.g:376:3: this_Button_0= ruleButton
                    {

                    			newCompositeNode(grammarAccess.getControlAccess().getButtonParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Button_0=ruleButton();

                    state._fsp--;


                    			current = this_Button_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:385:3: this_TextField_1= ruleTextField
                    {

                    			newCompositeNode(grammarAccess.getControlAccess().getTextFieldParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TextField_1=ruleTextField();

                    state._fsp--;


                    			current = this_TextField_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalGuiPro.g:394:3: this_CheckBox_2= ruleCheckBox
                    {

                    			newCompositeNode(grammarAccess.getControlAccess().getCheckBoxParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_CheckBox_2=ruleCheckBox();

                    state._fsp--;


                    			current = this_CheckBox_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalGuiPro.g:403:3: this_Label_3= ruleLabel
                    {

                    			newCompositeNode(grammarAccess.getControlAccess().getLabelParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Label_3=ruleLabel();

                    state._fsp--;


                    			current = this_Label_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalGuiPro.g:412:3: this_ListView_4= ruleListView
                    {

                    			newCompositeNode(grammarAccess.getControlAccess().getListViewParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_ListView_4=ruleListView();

                    state._fsp--;


                    			current = this_ListView_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleControl"


    // $ANTLR start "entryRuleButton"
    // InternalGuiPro.g:424:1: entryRuleButton returns [EObject current=null] : iv_ruleButton= ruleButton EOF ;
    public final EObject entryRuleButton() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleButton = null;


        try {
            // InternalGuiPro.g:424:47: (iv_ruleButton= ruleButton EOF )
            // InternalGuiPro.g:425:2: iv_ruleButton= ruleButton EOF
            {
             newCompositeNode(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleButton=ruleButton();

            state._fsp--;

             current =iv_ruleButton; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // InternalGuiPro.g:431:1: ruleButton returns [EObject current=null] : (otherlv_0= 'button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) ;
    public final EObject ruleButton() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_center_2_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:437:2: ( (otherlv_0= 'button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) )
            // InternalGuiPro.g:438:2: (otherlv_0= 'button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            {
            // InternalGuiPro.g:438:2: (otherlv_0= 'button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            // InternalGuiPro.g:439:3: otherlv_0= 'button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )?
            {
            otherlv_0=(Token)match(input,17,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getButtonAccess().getButtonKeyword_0());
            		
            // InternalGuiPro.g:443:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:444:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:444:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:445:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_1_0, grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getButtonRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:461:3: ( (lv_center_2_0= ruleText ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==25) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalGuiPro.g:462:4: (lv_center_2_0= ruleText )
                    {
                    // InternalGuiPro.g:462:4: (lv_center_2_0= ruleText )
                    // InternalGuiPro.g:463:5: lv_center_2_0= ruleText
                    {

                    					newCompositeNode(grammarAccess.getButtonAccess().getCenterTextParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_center_2_0=ruleText();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getButtonRule());
                    					}
                    					set(
                    						current,
                    						"center",
                    						lv_center_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Text");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGuiPro.g:480:3: ( (lv_right_3_0= ruleSize ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==22) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalGuiPro.g:481:4: (lv_right_3_0= ruleSize )
                    {
                    // InternalGuiPro.g:481:4: (lv_right_3_0= ruleSize )
                    // InternalGuiPro.g:482:5: lv_right_3_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getButtonAccess().getRightSizeParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_right_3_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getButtonRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_3_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleTextField"
    // InternalGuiPro.g:503:1: entryRuleTextField returns [EObject current=null] : iv_ruleTextField= ruleTextField EOF ;
    public final EObject entryRuleTextField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTextField = null;


        try {
            // InternalGuiPro.g:503:50: (iv_ruleTextField= ruleTextField EOF )
            // InternalGuiPro.g:504:2: iv_ruleTextField= ruleTextField EOF
            {
             newCompositeNode(grammarAccess.getTextFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTextField=ruleTextField();

            state._fsp--;

             current =iv_ruleTextField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTextField"


    // $ANTLR start "ruleTextField"
    // InternalGuiPro.g:510:1: ruleTextField returns [EObject current=null] : (otherlv_0= 'textField' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) ;
    public final EObject ruleTextField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_center_2_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:516:2: ( (otherlv_0= 'textField' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) )
            // InternalGuiPro.g:517:2: (otherlv_0= 'textField' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            {
            // InternalGuiPro.g:517:2: (otherlv_0= 'textField' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            // InternalGuiPro.g:518:3: otherlv_0= 'textField' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )?
            {
            otherlv_0=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getTextFieldAccess().getTextFieldKeyword_0());
            		
            // InternalGuiPro.g:522:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:523:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:523:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:524:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_1_0, grammarAccess.getTextFieldAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTextFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:540:3: ( (lv_center_2_0= ruleText ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==25) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalGuiPro.g:541:4: (lv_center_2_0= ruleText )
                    {
                    // InternalGuiPro.g:541:4: (lv_center_2_0= ruleText )
                    // InternalGuiPro.g:542:5: lv_center_2_0= ruleText
                    {

                    					newCompositeNode(grammarAccess.getTextFieldAccess().getCenterTextParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_center_2_0=ruleText();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTextFieldRule());
                    					}
                    					set(
                    						current,
                    						"center",
                    						lv_center_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Text");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGuiPro.g:559:3: ( (lv_right_3_0= ruleSize ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==22) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalGuiPro.g:560:4: (lv_right_3_0= ruleSize )
                    {
                    // InternalGuiPro.g:560:4: (lv_right_3_0= ruleSize )
                    // InternalGuiPro.g:561:5: lv_right_3_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getTextFieldAccess().getRightSizeParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_right_3_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTextFieldRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_3_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTextField"


    // $ANTLR start "entryRuleCheckBox"
    // InternalGuiPro.g:582:1: entryRuleCheckBox returns [EObject current=null] : iv_ruleCheckBox= ruleCheckBox EOF ;
    public final EObject entryRuleCheckBox() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCheckBox = null;


        try {
            // InternalGuiPro.g:582:49: (iv_ruleCheckBox= ruleCheckBox EOF )
            // InternalGuiPro.g:583:2: iv_ruleCheckBox= ruleCheckBox EOF
            {
             newCompositeNode(grammarAccess.getCheckBoxRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCheckBox=ruleCheckBox();

            state._fsp--;

             current =iv_ruleCheckBox; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCheckBox"


    // $ANTLR start "ruleCheckBox"
    // InternalGuiPro.g:589:1: ruleCheckBox returns [EObject current=null] : (otherlv_0= 'checkBox' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) ;
    public final EObject ruleCheckBox() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_center_2_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:595:2: ( (otherlv_0= 'checkBox' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) )
            // InternalGuiPro.g:596:2: (otherlv_0= 'checkBox' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            {
            // InternalGuiPro.g:596:2: (otherlv_0= 'checkBox' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            // InternalGuiPro.g:597:3: otherlv_0= 'checkBox' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )?
            {
            otherlv_0=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getCheckBoxAccess().getCheckBoxKeyword_0());
            		
            // InternalGuiPro.g:601:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:602:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:602:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:603:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCheckBoxAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCheckBoxRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:619:3: ( (lv_center_2_0= ruleText ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==25) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalGuiPro.g:620:4: (lv_center_2_0= ruleText )
                    {
                    // InternalGuiPro.g:620:4: (lv_center_2_0= ruleText )
                    // InternalGuiPro.g:621:5: lv_center_2_0= ruleText
                    {

                    					newCompositeNode(grammarAccess.getCheckBoxAccess().getCenterTextParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_center_2_0=ruleText();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCheckBoxRule());
                    					}
                    					set(
                    						current,
                    						"center",
                    						lv_center_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Text");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGuiPro.g:638:3: ( (lv_right_3_0= ruleSize ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==22) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalGuiPro.g:639:4: (lv_right_3_0= ruleSize )
                    {
                    // InternalGuiPro.g:639:4: (lv_right_3_0= ruleSize )
                    // InternalGuiPro.g:640:5: lv_right_3_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getCheckBoxAccess().getRightSizeParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_right_3_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCheckBoxRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_3_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCheckBox"


    // $ANTLR start "entryRuleLabel"
    // InternalGuiPro.g:661:1: entryRuleLabel returns [EObject current=null] : iv_ruleLabel= ruleLabel EOF ;
    public final EObject entryRuleLabel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLabel = null;


        try {
            // InternalGuiPro.g:661:46: (iv_ruleLabel= ruleLabel EOF )
            // InternalGuiPro.g:662:2: iv_ruleLabel= ruleLabel EOF
            {
             newCompositeNode(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLabel=ruleLabel();

            state._fsp--;

             current =iv_ruleLabel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // InternalGuiPro.g:668:1: ruleLabel returns [EObject current=null] : (otherlv_0= 'label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) ;
    public final EObject ruleLabel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_center_2_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:674:2: ( (otherlv_0= 'label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? ) )
            // InternalGuiPro.g:675:2: (otherlv_0= 'label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            {
            // InternalGuiPro.g:675:2: (otherlv_0= 'label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )? )
            // InternalGuiPro.g:676:3: otherlv_0= 'label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_center_2_0= ruleText ) )? ( (lv_right_3_0= ruleSize ) )?
            {
            otherlv_0=(Token)match(input,20,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getLabelAccess().getLabelKeyword_0());
            		
            // InternalGuiPro.g:680:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:681:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:681:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:682:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_1_0, grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLabelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:698:3: ( (lv_center_2_0= ruleText ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==25) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalGuiPro.g:699:4: (lv_center_2_0= ruleText )
                    {
                    // InternalGuiPro.g:699:4: (lv_center_2_0= ruleText )
                    // InternalGuiPro.g:700:5: lv_center_2_0= ruleText
                    {

                    					newCompositeNode(grammarAccess.getLabelAccess().getCenterTextParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_center_2_0=ruleText();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLabelRule());
                    					}
                    					set(
                    						current,
                    						"center",
                    						lv_center_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Text");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalGuiPro.g:717:3: ( (lv_right_3_0= ruleSize ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==22) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalGuiPro.g:718:4: (lv_right_3_0= ruleSize )
                    {
                    // InternalGuiPro.g:718:4: (lv_right_3_0= ruleSize )
                    // InternalGuiPro.g:719:5: lv_right_3_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getLabelAccess().getRightSizeParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_right_3_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLabelRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_3_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleListView"
    // InternalGuiPro.g:740:1: entryRuleListView returns [EObject current=null] : iv_ruleListView= ruleListView EOF ;
    public final EObject entryRuleListView() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListView = null;


        try {
            // InternalGuiPro.g:740:49: (iv_ruleListView= ruleListView EOF )
            // InternalGuiPro.g:741:2: iv_ruleListView= ruleListView EOF
            {
             newCompositeNode(grammarAccess.getListViewRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleListView=ruleListView();

            state._fsp--;

             current =iv_ruleListView; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListView"


    // $ANTLR start "ruleListView"
    // InternalGuiPro.g:747:1: ruleListView returns [EObject current=null] : (otherlv_0= 'listView' ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? ) ;
    public final EObject ruleListView() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_right_2_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:753:2: ( (otherlv_0= 'listView' ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? ) )
            // InternalGuiPro.g:754:2: (otherlv_0= 'listView' ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? )
            {
            // InternalGuiPro.g:754:2: (otherlv_0= 'listView' ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )? )
            // InternalGuiPro.g:755:3: otherlv_0= 'listView' ( (lv_name_1_0= RULE_ID ) ) ( (lv_right_2_0= ruleSize ) )?
            {
            otherlv_0=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getListViewAccess().getListViewKeyword_0());
            		
            // InternalGuiPro.g:759:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalGuiPro.g:760:4: (lv_name_1_0= RULE_ID )
            {
            // InternalGuiPro.g:760:4: (lv_name_1_0= RULE_ID )
            // InternalGuiPro.g:761:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_name_1_0, grammarAccess.getListViewAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getListViewRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalGuiPro.g:777:3: ( (lv_right_2_0= ruleSize ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==22) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalGuiPro.g:778:4: (lv_right_2_0= ruleSize )
                    {
                    // InternalGuiPro.g:778:4: (lv_right_2_0= ruleSize )
                    // InternalGuiPro.g:779:5: lv_right_2_0= ruleSize
                    {

                    					newCompositeNode(grammarAccess.getListViewAccess().getRightSizeParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_right_2_0=ruleSize();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getListViewRule());
                    					}
                    					set(
                    						current,
                    						"right",
                    						lv_right_2_0,
                    						"org.xtext.mdsd.guipro.GuiPro.Size");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListView"


    // $ANTLR start "entryRuleSize"
    // InternalGuiPro.g:800:1: entryRuleSize returns [EObject current=null] : iv_ruleSize= ruleSize EOF ;
    public final EObject entryRuleSize() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSize = null;


        try {
            // InternalGuiPro.g:800:45: (iv_ruleSize= ruleSize EOF )
            // InternalGuiPro.g:801:2: iv_ruleSize= ruleSize EOF
            {
             newCompositeNode(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSize=ruleSize();

            state._fsp--;

             current =iv_ruleSize; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // InternalGuiPro.g:807:1: ruleSize returns [EObject current=null] : (otherlv_0= '(' ( (lv_x_1_0= ruleNumber ) ) otherlv_2= ',' ( (lv_y_3_0= ruleNumber ) ) otherlv_4= ')' ) ;
    public final EObject ruleSize() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_x_1_0 = null;

        AntlrDatatypeRuleToken lv_y_3_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:813:2: ( (otherlv_0= '(' ( (lv_x_1_0= ruleNumber ) ) otherlv_2= ',' ( (lv_y_3_0= ruleNumber ) ) otherlv_4= ')' ) )
            // InternalGuiPro.g:814:2: (otherlv_0= '(' ( (lv_x_1_0= ruleNumber ) ) otherlv_2= ',' ( (lv_y_3_0= ruleNumber ) ) otherlv_4= ')' )
            {
            // InternalGuiPro.g:814:2: (otherlv_0= '(' ( (lv_x_1_0= ruleNumber ) ) otherlv_2= ',' ( (lv_y_3_0= ruleNumber ) ) otherlv_4= ')' )
            // InternalGuiPro.g:815:3: otherlv_0= '(' ( (lv_x_1_0= ruleNumber ) ) otherlv_2= ',' ( (lv_y_3_0= ruleNumber ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getSizeAccess().getLeftParenthesisKeyword_0());
            		
            // InternalGuiPro.g:819:3: ( (lv_x_1_0= ruleNumber ) )
            // InternalGuiPro.g:820:4: (lv_x_1_0= ruleNumber )
            {
            // InternalGuiPro.g:820:4: (lv_x_1_0= ruleNumber )
            // InternalGuiPro.g:821:5: lv_x_1_0= ruleNumber
            {

            					newCompositeNode(grammarAccess.getSizeAccess().getXNumberParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_12);
            lv_x_1_0=ruleNumber();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSizeRule());
            					}
            					set(
            						current,
            						"x",
            						lv_x_1_0,
            						"org.xtext.mdsd.guipro.GuiPro.Number");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getSizeAccess().getCommaKeyword_2());
            		
            // InternalGuiPro.g:842:3: ( (lv_y_3_0= ruleNumber ) )
            // InternalGuiPro.g:843:4: (lv_y_3_0= ruleNumber )
            {
            // InternalGuiPro.g:843:4: (lv_y_3_0= ruleNumber )
            // InternalGuiPro.g:844:5: lv_y_3_0= ruleNumber
            {

            					newCompositeNode(grammarAccess.getSizeAccess().getYNumberParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_13);
            lv_y_3_0=ruleNumber();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSizeRule());
            					}
            					set(
            						current,
            						"y",
            						lv_y_3_0,
            						"org.xtext.mdsd.guipro.GuiPro.Number");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getSizeAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRuleNumber"
    // InternalGuiPro.g:869:1: entryRuleNumber returns [String current=null] : iv_ruleNumber= ruleNumber EOF ;
    public final String entryRuleNumber() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNumber = null;


        try {
            // InternalGuiPro.g:869:46: (iv_ruleNumber= ruleNumber EOF )
            // InternalGuiPro.g:870:2: iv_ruleNumber= ruleNumber EOF
            {
             newCompositeNode(grammarAccess.getNumberRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNumber=ruleNumber();

            state._fsp--;

             current =iv_ruleNumber.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumber"


    // $ANTLR start "ruleNumber"
    // InternalGuiPro.g:876:1: ruleNumber returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_INT_0= RULE_INT ;
    public final AntlrDatatypeRuleToken ruleNumber() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;


        	enterRule();

        try {
            // InternalGuiPro.g:882:2: (this_INT_0= RULE_INT )
            // InternalGuiPro.g:883:2: this_INT_0= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            		current.merge(this_INT_0);
            	

            		newLeafNode(this_INT_0, grammarAccess.getNumberAccess().getINTTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumber"


    // $ANTLR start "entryRuleText"
    // InternalGuiPro.g:893:1: entryRuleText returns [EObject current=null] : iv_ruleText= ruleText EOF ;
    public final EObject entryRuleText() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleText = null;


        try {
            // InternalGuiPro.g:893:45: (iv_ruleText= ruleText EOF )
            // InternalGuiPro.g:894:2: iv_ruleText= ruleText EOF
            {
             newCompositeNode(grammarAccess.getTextRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleText=ruleText();

            state._fsp--;

             current =iv_ruleText; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleText"


    // $ANTLR start "ruleText"
    // InternalGuiPro.g:900:1: ruleText returns [EObject current=null] : (otherlv_0= ':' ( (lv_value_1_0= ruleInput ) ) ) ;
    public final EObject ruleText() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_value_1_0 = null;



        	enterRule();

        try {
            // InternalGuiPro.g:906:2: ( (otherlv_0= ':' ( (lv_value_1_0= ruleInput ) ) ) )
            // InternalGuiPro.g:907:2: (otherlv_0= ':' ( (lv_value_1_0= ruleInput ) ) )
            {
            // InternalGuiPro.g:907:2: (otherlv_0= ':' ( (lv_value_1_0= ruleInput ) ) )
            // InternalGuiPro.g:908:3: otherlv_0= ':' ( (lv_value_1_0= ruleInput ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getTextAccess().getColonKeyword_0());
            		
            // InternalGuiPro.g:912:3: ( (lv_value_1_0= ruleInput ) )
            // InternalGuiPro.g:913:4: (lv_value_1_0= ruleInput )
            {
            // InternalGuiPro.g:913:4: (lv_value_1_0= ruleInput )
            // InternalGuiPro.g:914:5: lv_value_1_0= ruleInput
            {

            					newCompositeNode(grammarAccess.getTextAccess().getValueInputParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_1_0=ruleInput();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTextRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.xtext.mdsd.guipro.GuiPro.Input");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleText"


    // $ANTLR start "entryRuleInput"
    // InternalGuiPro.g:935:1: entryRuleInput returns [String current=null] : iv_ruleInput= ruleInput EOF ;
    public final String entryRuleInput() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleInput = null;


        try {
            // InternalGuiPro.g:935:45: (iv_ruleInput= ruleInput EOF )
            // InternalGuiPro.g:936:2: iv_ruleInput= ruleInput EOF
            {
             newCompositeNode(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInput=ruleInput();

            state._fsp--;

             current =iv_ruleInput.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalGuiPro.g:942:1: ruleInput returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_STRING_0= RULE_STRING ;
    public final AntlrDatatypeRuleToken ruleInput() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;


        	enterRule();

        try {
            // InternalGuiPro.g:948:2: (this_STRING_0= RULE_STRING )
            // InternalGuiPro.g:949:2: this_STRING_0= RULE_STRING
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            		current.merge(this_STRING_0);
            	

            		newLeafNode(this_STRING_0, grammarAccess.getInputAccess().getSTRINGTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInput"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000002402000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000402000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000001C000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000003FC000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000002400002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000040L});

}