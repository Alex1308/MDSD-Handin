package org.xtext.mdsd.guipro.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.mdsd.guipro.services.GuiProGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGuiProParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_STRING", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'frame.vertical'", "'frame.horizontal'", "'panel.vertical'", "'panel.horizontal'", "'{'", "'}'", "'button'", "'textField'", "'checkBox'", "'label'", "'listView'", "'('", "','", "')'", "':'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=6;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=4;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalGuiProParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGuiProParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGuiProParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGuiPro.g"; }


    	private GuiProGrammarAccess grammarAccess;

    	public void setGrammarAccess(GuiProGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSystem"
    // InternalGuiPro.g:53:1: entryRuleSystem : ruleSystem EOF ;
    public final void entryRuleSystem() throws RecognitionException {
        try {
            // InternalGuiPro.g:54:1: ( ruleSystem EOF )
            // InternalGuiPro.g:55:1: ruleSystem EOF
            {
             before(grammarAccess.getSystemRule()); 
            pushFollow(FOLLOW_1);
            ruleSystem();

            state._fsp--;

             after(grammarAccess.getSystemRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSystem"


    // $ANTLR start "ruleSystem"
    // InternalGuiPro.g:62:1: ruleSystem : ( ( rule__System__FramesAssignment ) ) ;
    public final void ruleSystem() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:66:2: ( ( ( rule__System__FramesAssignment ) ) )
            // InternalGuiPro.g:67:2: ( ( rule__System__FramesAssignment ) )
            {
            // InternalGuiPro.g:67:2: ( ( rule__System__FramesAssignment ) )
            // InternalGuiPro.g:68:3: ( rule__System__FramesAssignment )
            {
             before(grammarAccess.getSystemAccess().getFramesAssignment()); 
            // InternalGuiPro.g:69:3: ( rule__System__FramesAssignment )
            // InternalGuiPro.g:69:4: rule__System__FramesAssignment
            {
            pushFollow(FOLLOW_2);
            rule__System__FramesAssignment();

            state._fsp--;


            }

             after(grammarAccess.getSystemAccess().getFramesAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSystem"


    // $ANTLR start "entryRuleFrame"
    // InternalGuiPro.g:78:1: entryRuleFrame : ruleFrame EOF ;
    public final void entryRuleFrame() throws RecognitionException {
        try {
            // InternalGuiPro.g:79:1: ( ruleFrame EOF )
            // InternalGuiPro.g:80:1: ruleFrame EOF
            {
             before(grammarAccess.getFrameRule()); 
            pushFollow(FOLLOW_1);
            ruleFrame();

            state._fsp--;

             after(grammarAccess.getFrameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFrame"


    // $ANTLR start "ruleFrame"
    // InternalGuiPro.g:87:1: ruleFrame : ( ( rule__Frame__Group__0 ) ) ;
    public final void ruleFrame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:91:2: ( ( ( rule__Frame__Group__0 ) ) )
            // InternalGuiPro.g:92:2: ( ( rule__Frame__Group__0 ) )
            {
            // InternalGuiPro.g:92:2: ( ( rule__Frame__Group__0 ) )
            // InternalGuiPro.g:93:3: ( rule__Frame__Group__0 )
            {
             before(grammarAccess.getFrameAccess().getGroup()); 
            // InternalGuiPro.g:94:3: ( rule__Frame__Group__0 )
            // InternalGuiPro.g:94:4: rule__Frame__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Frame__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFrameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFrame"


    // $ANTLR start "entryRulePanel"
    // InternalGuiPro.g:103:1: entryRulePanel : rulePanel EOF ;
    public final void entryRulePanel() throws RecognitionException {
        try {
            // InternalGuiPro.g:104:1: ( rulePanel EOF )
            // InternalGuiPro.g:105:1: rulePanel EOF
            {
             before(grammarAccess.getPanelRule()); 
            pushFollow(FOLLOW_1);
            rulePanel();

            state._fsp--;

             after(grammarAccess.getPanelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePanel"


    // $ANTLR start "rulePanel"
    // InternalGuiPro.g:112:1: rulePanel : ( ( rule__Panel__Group__0 ) ) ;
    public final void rulePanel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:116:2: ( ( ( rule__Panel__Group__0 ) ) )
            // InternalGuiPro.g:117:2: ( ( rule__Panel__Group__0 ) )
            {
            // InternalGuiPro.g:117:2: ( ( rule__Panel__Group__0 ) )
            // InternalGuiPro.g:118:3: ( rule__Panel__Group__0 )
            {
             before(grammarAccess.getPanelAccess().getGroup()); 
            // InternalGuiPro.g:119:3: ( rule__Panel__Group__0 )
            // InternalGuiPro.g:119:4: rule__Panel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Panel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPanelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePanel"


    // $ANTLR start "entryRuleControl"
    // InternalGuiPro.g:128:1: entryRuleControl : ruleControl EOF ;
    public final void entryRuleControl() throws RecognitionException {
        try {
            // InternalGuiPro.g:129:1: ( ruleControl EOF )
            // InternalGuiPro.g:130:1: ruleControl EOF
            {
             before(grammarAccess.getControlRule()); 
            pushFollow(FOLLOW_1);
            ruleControl();

            state._fsp--;

             after(grammarAccess.getControlRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleControl"


    // $ANTLR start "ruleControl"
    // InternalGuiPro.g:137:1: ruleControl : ( ( rule__Control__Alternatives ) ) ;
    public final void ruleControl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:141:2: ( ( ( rule__Control__Alternatives ) ) )
            // InternalGuiPro.g:142:2: ( ( rule__Control__Alternatives ) )
            {
            // InternalGuiPro.g:142:2: ( ( rule__Control__Alternatives ) )
            // InternalGuiPro.g:143:3: ( rule__Control__Alternatives )
            {
             before(grammarAccess.getControlAccess().getAlternatives()); 
            // InternalGuiPro.g:144:3: ( rule__Control__Alternatives )
            // InternalGuiPro.g:144:4: rule__Control__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Control__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getControlAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleControl"


    // $ANTLR start "entryRuleButton"
    // InternalGuiPro.g:153:1: entryRuleButton : ruleButton EOF ;
    public final void entryRuleButton() throws RecognitionException {
        try {
            // InternalGuiPro.g:154:1: ( ruleButton EOF )
            // InternalGuiPro.g:155:1: ruleButton EOF
            {
             before(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_1);
            ruleButton();

            state._fsp--;

             after(grammarAccess.getButtonRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // InternalGuiPro.g:162:1: ruleButton : ( ( rule__Button__Group__0 ) ) ;
    public final void ruleButton() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:166:2: ( ( ( rule__Button__Group__0 ) ) )
            // InternalGuiPro.g:167:2: ( ( rule__Button__Group__0 ) )
            {
            // InternalGuiPro.g:167:2: ( ( rule__Button__Group__0 ) )
            // InternalGuiPro.g:168:3: ( rule__Button__Group__0 )
            {
             before(grammarAccess.getButtonAccess().getGroup()); 
            // InternalGuiPro.g:169:3: ( rule__Button__Group__0 )
            // InternalGuiPro.g:169:4: rule__Button__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Button__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleTextField"
    // InternalGuiPro.g:178:1: entryRuleTextField : ruleTextField EOF ;
    public final void entryRuleTextField() throws RecognitionException {
        try {
            // InternalGuiPro.g:179:1: ( ruleTextField EOF )
            // InternalGuiPro.g:180:1: ruleTextField EOF
            {
             before(grammarAccess.getTextFieldRule()); 
            pushFollow(FOLLOW_1);
            ruleTextField();

            state._fsp--;

             after(grammarAccess.getTextFieldRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTextField"


    // $ANTLR start "ruleTextField"
    // InternalGuiPro.g:187:1: ruleTextField : ( ( rule__TextField__Group__0 ) ) ;
    public final void ruleTextField() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:191:2: ( ( ( rule__TextField__Group__0 ) ) )
            // InternalGuiPro.g:192:2: ( ( rule__TextField__Group__0 ) )
            {
            // InternalGuiPro.g:192:2: ( ( rule__TextField__Group__0 ) )
            // InternalGuiPro.g:193:3: ( rule__TextField__Group__0 )
            {
             before(grammarAccess.getTextFieldAccess().getGroup()); 
            // InternalGuiPro.g:194:3: ( rule__TextField__Group__0 )
            // InternalGuiPro.g:194:4: rule__TextField__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TextField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTextFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTextField"


    // $ANTLR start "entryRuleCheckBox"
    // InternalGuiPro.g:203:1: entryRuleCheckBox : ruleCheckBox EOF ;
    public final void entryRuleCheckBox() throws RecognitionException {
        try {
            // InternalGuiPro.g:204:1: ( ruleCheckBox EOF )
            // InternalGuiPro.g:205:1: ruleCheckBox EOF
            {
             before(grammarAccess.getCheckBoxRule()); 
            pushFollow(FOLLOW_1);
            ruleCheckBox();

            state._fsp--;

             after(grammarAccess.getCheckBoxRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCheckBox"


    // $ANTLR start "ruleCheckBox"
    // InternalGuiPro.g:212:1: ruleCheckBox : ( ( rule__CheckBox__Group__0 ) ) ;
    public final void ruleCheckBox() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:216:2: ( ( ( rule__CheckBox__Group__0 ) ) )
            // InternalGuiPro.g:217:2: ( ( rule__CheckBox__Group__0 ) )
            {
            // InternalGuiPro.g:217:2: ( ( rule__CheckBox__Group__0 ) )
            // InternalGuiPro.g:218:3: ( rule__CheckBox__Group__0 )
            {
             before(grammarAccess.getCheckBoxAccess().getGroup()); 
            // InternalGuiPro.g:219:3: ( rule__CheckBox__Group__0 )
            // InternalGuiPro.g:219:4: rule__CheckBox__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__CheckBox__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCheckBoxAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCheckBox"


    // $ANTLR start "entryRuleLabel"
    // InternalGuiPro.g:228:1: entryRuleLabel : ruleLabel EOF ;
    public final void entryRuleLabel() throws RecognitionException {
        try {
            // InternalGuiPro.g:229:1: ( ruleLabel EOF )
            // InternalGuiPro.g:230:1: ruleLabel EOF
            {
             before(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_1);
            ruleLabel();

            state._fsp--;

             after(grammarAccess.getLabelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // InternalGuiPro.g:237:1: ruleLabel : ( ( rule__Label__Group__0 ) ) ;
    public final void ruleLabel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:241:2: ( ( ( rule__Label__Group__0 ) ) )
            // InternalGuiPro.g:242:2: ( ( rule__Label__Group__0 ) )
            {
            // InternalGuiPro.g:242:2: ( ( rule__Label__Group__0 ) )
            // InternalGuiPro.g:243:3: ( rule__Label__Group__0 )
            {
             before(grammarAccess.getLabelAccess().getGroup()); 
            // InternalGuiPro.g:244:3: ( rule__Label__Group__0 )
            // InternalGuiPro.g:244:4: rule__Label__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Label__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleListView"
    // InternalGuiPro.g:253:1: entryRuleListView : ruleListView EOF ;
    public final void entryRuleListView() throws RecognitionException {
        try {
            // InternalGuiPro.g:254:1: ( ruleListView EOF )
            // InternalGuiPro.g:255:1: ruleListView EOF
            {
             before(grammarAccess.getListViewRule()); 
            pushFollow(FOLLOW_1);
            ruleListView();

            state._fsp--;

             after(grammarAccess.getListViewRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListView"


    // $ANTLR start "ruleListView"
    // InternalGuiPro.g:262:1: ruleListView : ( ( rule__ListView__Group__0 ) ) ;
    public final void ruleListView() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:266:2: ( ( ( rule__ListView__Group__0 ) ) )
            // InternalGuiPro.g:267:2: ( ( rule__ListView__Group__0 ) )
            {
            // InternalGuiPro.g:267:2: ( ( rule__ListView__Group__0 ) )
            // InternalGuiPro.g:268:3: ( rule__ListView__Group__0 )
            {
             before(grammarAccess.getListViewAccess().getGroup()); 
            // InternalGuiPro.g:269:3: ( rule__ListView__Group__0 )
            // InternalGuiPro.g:269:4: rule__ListView__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListView__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListViewAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListView"


    // $ANTLR start "entryRuleSize"
    // InternalGuiPro.g:278:1: entryRuleSize : ruleSize EOF ;
    public final void entryRuleSize() throws RecognitionException {
        try {
            // InternalGuiPro.g:279:1: ( ruleSize EOF )
            // InternalGuiPro.g:280:1: ruleSize EOF
            {
             before(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_1);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getSizeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // InternalGuiPro.g:287:1: ruleSize : ( ( rule__Size__Group__0 ) ) ;
    public final void ruleSize() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:291:2: ( ( ( rule__Size__Group__0 ) ) )
            // InternalGuiPro.g:292:2: ( ( rule__Size__Group__0 ) )
            {
            // InternalGuiPro.g:292:2: ( ( rule__Size__Group__0 ) )
            // InternalGuiPro.g:293:3: ( rule__Size__Group__0 )
            {
             before(grammarAccess.getSizeAccess().getGroup()); 
            // InternalGuiPro.g:294:3: ( rule__Size__Group__0 )
            // InternalGuiPro.g:294:4: rule__Size__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Size__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRuleNumber"
    // InternalGuiPro.g:303:1: entryRuleNumber : ruleNumber EOF ;
    public final void entryRuleNumber() throws RecognitionException {
        try {
            // InternalGuiPro.g:304:1: ( ruleNumber EOF )
            // InternalGuiPro.g:305:1: ruleNumber EOF
            {
             before(grammarAccess.getNumberRule()); 
            pushFollow(FOLLOW_1);
            ruleNumber();

            state._fsp--;

             after(grammarAccess.getNumberRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNumber"


    // $ANTLR start "ruleNumber"
    // InternalGuiPro.g:312:1: ruleNumber : ( RULE_INT ) ;
    public final void ruleNumber() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:316:2: ( ( RULE_INT ) )
            // InternalGuiPro.g:317:2: ( RULE_INT )
            {
            // InternalGuiPro.g:317:2: ( RULE_INT )
            // InternalGuiPro.g:318:3: RULE_INT
            {
             before(grammarAccess.getNumberAccess().getINTTerminalRuleCall()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getNumberAccess().getINTTerminalRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNumber"


    // $ANTLR start "entryRuleText"
    // InternalGuiPro.g:328:1: entryRuleText : ruleText EOF ;
    public final void entryRuleText() throws RecognitionException {
        try {
            // InternalGuiPro.g:329:1: ( ruleText EOF )
            // InternalGuiPro.g:330:1: ruleText EOF
            {
             before(grammarAccess.getTextRule()); 
            pushFollow(FOLLOW_1);
            ruleText();

            state._fsp--;

             after(grammarAccess.getTextRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleText"


    // $ANTLR start "ruleText"
    // InternalGuiPro.g:337:1: ruleText : ( ( rule__Text__Group__0 ) ) ;
    public final void ruleText() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:341:2: ( ( ( rule__Text__Group__0 ) ) )
            // InternalGuiPro.g:342:2: ( ( rule__Text__Group__0 ) )
            {
            // InternalGuiPro.g:342:2: ( ( rule__Text__Group__0 ) )
            // InternalGuiPro.g:343:3: ( rule__Text__Group__0 )
            {
             before(grammarAccess.getTextAccess().getGroup()); 
            // InternalGuiPro.g:344:3: ( rule__Text__Group__0 )
            // InternalGuiPro.g:344:4: rule__Text__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Text__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTextAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleText"


    // $ANTLR start "entryRuleInput"
    // InternalGuiPro.g:353:1: entryRuleInput : ruleInput EOF ;
    public final void entryRuleInput() throws RecognitionException {
        try {
            // InternalGuiPro.g:354:1: ( ruleInput EOF )
            // InternalGuiPro.g:355:1: ruleInput EOF
            {
             before(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            ruleInput();

            state._fsp--;

             after(grammarAccess.getInputRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalGuiPro.g:362:1: ruleInput : ( RULE_STRING ) ;
    public final void ruleInput() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:366:2: ( ( RULE_STRING ) )
            // InternalGuiPro.g:367:2: ( RULE_STRING )
            {
            // InternalGuiPro.g:367:2: ( RULE_STRING )
            // InternalGuiPro.g:368:3: RULE_STRING
            {
             before(grammarAccess.getInputAccess().getSTRINGTerminalRuleCall()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getSTRINGTerminalRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "rule__Frame__LeftAlternatives_0_0"
    // InternalGuiPro.g:377:1: rule__Frame__LeftAlternatives_0_0 : ( ( 'frame.vertical' ) | ( 'frame.horizontal' ) );
    public final void rule__Frame__LeftAlternatives_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:381:1: ( ( 'frame.vertical' ) | ( 'frame.horizontal' ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            else if ( (LA1_0==12) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalGuiPro.g:382:2: ( 'frame.vertical' )
                    {
                    // InternalGuiPro.g:382:2: ( 'frame.vertical' )
                    // InternalGuiPro.g:383:3: 'frame.vertical'
                    {
                     before(grammarAccess.getFrameAccess().getLeftFrameVerticalKeyword_0_0_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getFrameAccess().getLeftFrameVerticalKeyword_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:388:2: ( 'frame.horizontal' )
                    {
                    // InternalGuiPro.g:388:2: ( 'frame.horizontal' )
                    // InternalGuiPro.g:389:3: 'frame.horizontal'
                    {
                     before(grammarAccess.getFrameAccess().getLeftFrameHorizontalKeyword_0_0_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getFrameAccess().getLeftFrameHorizontalKeyword_0_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__LeftAlternatives_0_0"


    // $ANTLR start "rule__Panel__LeftAlternatives_0_0"
    // InternalGuiPro.g:398:1: rule__Panel__LeftAlternatives_0_0 : ( ( 'panel.vertical' ) | ( 'panel.horizontal' ) );
    public final void rule__Panel__LeftAlternatives_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:402:1: ( ( 'panel.vertical' ) | ( 'panel.horizontal' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            else if ( (LA2_0==14) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalGuiPro.g:403:2: ( 'panel.vertical' )
                    {
                    // InternalGuiPro.g:403:2: ( 'panel.vertical' )
                    // InternalGuiPro.g:404:3: 'panel.vertical'
                    {
                     before(grammarAccess.getPanelAccess().getLeftPanelVerticalKeyword_0_0_0()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getPanelAccess().getLeftPanelVerticalKeyword_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:409:2: ( 'panel.horizontal' )
                    {
                    // InternalGuiPro.g:409:2: ( 'panel.horizontal' )
                    // InternalGuiPro.g:410:3: 'panel.horizontal'
                    {
                     before(grammarAccess.getPanelAccess().getLeftPanelHorizontalKeyword_0_0_1()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getPanelAccess().getLeftPanelHorizontalKeyword_0_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__LeftAlternatives_0_0"


    // $ANTLR start "rule__Panel__Alternatives_4"
    // InternalGuiPro.g:419:1: rule__Panel__Alternatives_4 : ( ( ( rule__Panel__ControlsAssignment_4_0 ) ) | ( ( rule__Panel__PanelsAssignment_4_1 ) ) );
    public final void rule__Panel__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:423:1: ( ( ( rule__Panel__ControlsAssignment_4_0 ) ) | ( ( rule__Panel__PanelsAssignment_4_1 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( ((LA3_0>=17 && LA3_0<=21)) ) {
                alt3=1;
            }
            else if ( ((LA3_0>=13 && LA3_0<=14)) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalGuiPro.g:424:2: ( ( rule__Panel__ControlsAssignment_4_0 ) )
                    {
                    // InternalGuiPro.g:424:2: ( ( rule__Panel__ControlsAssignment_4_0 ) )
                    // InternalGuiPro.g:425:3: ( rule__Panel__ControlsAssignment_4_0 )
                    {
                     before(grammarAccess.getPanelAccess().getControlsAssignment_4_0()); 
                    // InternalGuiPro.g:426:3: ( rule__Panel__ControlsAssignment_4_0 )
                    // InternalGuiPro.g:426:4: rule__Panel__ControlsAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Panel__ControlsAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPanelAccess().getControlsAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:430:2: ( ( rule__Panel__PanelsAssignment_4_1 ) )
                    {
                    // InternalGuiPro.g:430:2: ( ( rule__Panel__PanelsAssignment_4_1 ) )
                    // InternalGuiPro.g:431:3: ( rule__Panel__PanelsAssignment_4_1 )
                    {
                     before(grammarAccess.getPanelAccess().getPanelsAssignment_4_1()); 
                    // InternalGuiPro.g:432:3: ( rule__Panel__PanelsAssignment_4_1 )
                    // InternalGuiPro.g:432:4: rule__Panel__PanelsAssignment_4_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Panel__PanelsAssignment_4_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getPanelAccess().getPanelsAssignment_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Alternatives_4"


    // $ANTLR start "rule__Control__Alternatives"
    // InternalGuiPro.g:440:1: rule__Control__Alternatives : ( ( ruleButton ) | ( ruleTextField ) | ( ruleCheckBox ) | ( ruleLabel ) | ( ruleListView ) );
    public final void rule__Control__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:444:1: ( ( ruleButton ) | ( ruleTextField ) | ( ruleCheckBox ) | ( ruleLabel ) | ( ruleListView ) )
            int alt4=5;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt4=1;
                }
                break;
            case 18:
                {
                alt4=2;
                }
                break;
            case 19:
                {
                alt4=3;
                }
                break;
            case 20:
                {
                alt4=4;
                }
                break;
            case 21:
                {
                alt4=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalGuiPro.g:445:2: ( ruleButton )
                    {
                    // InternalGuiPro.g:445:2: ( ruleButton )
                    // InternalGuiPro.g:446:3: ruleButton
                    {
                     before(grammarAccess.getControlAccess().getButtonParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleButton();

                    state._fsp--;

                     after(grammarAccess.getControlAccess().getButtonParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGuiPro.g:451:2: ( ruleTextField )
                    {
                    // InternalGuiPro.g:451:2: ( ruleTextField )
                    // InternalGuiPro.g:452:3: ruleTextField
                    {
                     before(grammarAccess.getControlAccess().getTextFieldParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTextField();

                    state._fsp--;

                     after(grammarAccess.getControlAccess().getTextFieldParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalGuiPro.g:457:2: ( ruleCheckBox )
                    {
                    // InternalGuiPro.g:457:2: ( ruleCheckBox )
                    // InternalGuiPro.g:458:3: ruleCheckBox
                    {
                     before(grammarAccess.getControlAccess().getCheckBoxParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleCheckBox();

                    state._fsp--;

                     after(grammarAccess.getControlAccess().getCheckBoxParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalGuiPro.g:463:2: ( ruleLabel )
                    {
                    // InternalGuiPro.g:463:2: ( ruleLabel )
                    // InternalGuiPro.g:464:3: ruleLabel
                    {
                     before(grammarAccess.getControlAccess().getLabelParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleLabel();

                    state._fsp--;

                     after(grammarAccess.getControlAccess().getLabelParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalGuiPro.g:469:2: ( ruleListView )
                    {
                    // InternalGuiPro.g:469:2: ( ruleListView )
                    // InternalGuiPro.g:470:3: ruleListView
                    {
                     before(grammarAccess.getControlAccess().getListViewParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleListView();

                    state._fsp--;

                     after(grammarAccess.getControlAccess().getListViewParserRuleCall_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Control__Alternatives"


    // $ANTLR start "rule__Frame__Group__0"
    // InternalGuiPro.g:479:1: rule__Frame__Group__0 : rule__Frame__Group__0__Impl rule__Frame__Group__1 ;
    public final void rule__Frame__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:483:1: ( rule__Frame__Group__0__Impl rule__Frame__Group__1 )
            // InternalGuiPro.g:484:2: rule__Frame__Group__0__Impl rule__Frame__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Frame__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__0"


    // $ANTLR start "rule__Frame__Group__0__Impl"
    // InternalGuiPro.g:491:1: rule__Frame__Group__0__Impl : ( ( rule__Frame__LeftAssignment_0 ) ) ;
    public final void rule__Frame__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:495:1: ( ( ( rule__Frame__LeftAssignment_0 ) ) )
            // InternalGuiPro.g:496:1: ( ( rule__Frame__LeftAssignment_0 ) )
            {
            // InternalGuiPro.g:496:1: ( ( rule__Frame__LeftAssignment_0 ) )
            // InternalGuiPro.g:497:2: ( rule__Frame__LeftAssignment_0 )
            {
             before(grammarAccess.getFrameAccess().getLeftAssignment_0()); 
            // InternalGuiPro.g:498:2: ( rule__Frame__LeftAssignment_0 )
            // InternalGuiPro.g:498:3: rule__Frame__LeftAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Frame__LeftAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFrameAccess().getLeftAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__0__Impl"


    // $ANTLR start "rule__Frame__Group__1"
    // InternalGuiPro.g:506:1: rule__Frame__Group__1 : rule__Frame__Group__1__Impl rule__Frame__Group__2 ;
    public final void rule__Frame__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:510:1: ( rule__Frame__Group__1__Impl rule__Frame__Group__2 )
            // InternalGuiPro.g:511:2: rule__Frame__Group__1__Impl rule__Frame__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Frame__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__1"


    // $ANTLR start "rule__Frame__Group__1__Impl"
    // InternalGuiPro.g:518:1: rule__Frame__Group__1__Impl : ( ( rule__Frame__NameAssignment_1 ) ) ;
    public final void rule__Frame__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:522:1: ( ( ( rule__Frame__NameAssignment_1 ) ) )
            // InternalGuiPro.g:523:1: ( ( rule__Frame__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:523:1: ( ( rule__Frame__NameAssignment_1 ) )
            // InternalGuiPro.g:524:2: ( rule__Frame__NameAssignment_1 )
            {
             before(grammarAccess.getFrameAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:525:2: ( rule__Frame__NameAssignment_1 )
            // InternalGuiPro.g:525:3: rule__Frame__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Frame__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFrameAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__1__Impl"


    // $ANTLR start "rule__Frame__Group__2"
    // InternalGuiPro.g:533:1: rule__Frame__Group__2 : rule__Frame__Group__2__Impl rule__Frame__Group__3 ;
    public final void rule__Frame__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:537:1: ( rule__Frame__Group__2__Impl rule__Frame__Group__3 )
            // InternalGuiPro.g:538:2: rule__Frame__Group__2__Impl rule__Frame__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Frame__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__2"


    // $ANTLR start "rule__Frame__Group__2__Impl"
    // InternalGuiPro.g:545:1: rule__Frame__Group__2__Impl : ( ( rule__Frame__CenterAssignment_2 )? ) ;
    public final void rule__Frame__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:549:1: ( ( ( rule__Frame__CenterAssignment_2 )? ) )
            // InternalGuiPro.g:550:1: ( ( rule__Frame__CenterAssignment_2 )? )
            {
            // InternalGuiPro.g:550:1: ( ( rule__Frame__CenterAssignment_2 )? )
            // InternalGuiPro.g:551:2: ( rule__Frame__CenterAssignment_2 )?
            {
             before(grammarAccess.getFrameAccess().getCenterAssignment_2()); 
            // InternalGuiPro.g:552:2: ( rule__Frame__CenterAssignment_2 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==25) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalGuiPro.g:552:3: rule__Frame__CenterAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Frame__CenterAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFrameAccess().getCenterAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__2__Impl"


    // $ANTLR start "rule__Frame__Group__3"
    // InternalGuiPro.g:560:1: rule__Frame__Group__3 : rule__Frame__Group__3__Impl rule__Frame__Group__4 ;
    public final void rule__Frame__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:564:1: ( rule__Frame__Group__3__Impl rule__Frame__Group__4 )
            // InternalGuiPro.g:565:2: rule__Frame__Group__3__Impl rule__Frame__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__Frame__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__3"


    // $ANTLR start "rule__Frame__Group__3__Impl"
    // InternalGuiPro.g:572:1: rule__Frame__Group__3__Impl : ( ( rule__Frame__RightAssignment_3 )? ) ;
    public final void rule__Frame__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:576:1: ( ( ( rule__Frame__RightAssignment_3 )? ) )
            // InternalGuiPro.g:577:1: ( ( rule__Frame__RightAssignment_3 )? )
            {
            // InternalGuiPro.g:577:1: ( ( rule__Frame__RightAssignment_3 )? )
            // InternalGuiPro.g:578:2: ( rule__Frame__RightAssignment_3 )?
            {
             before(grammarAccess.getFrameAccess().getRightAssignment_3()); 
            // InternalGuiPro.g:579:2: ( rule__Frame__RightAssignment_3 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==22) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalGuiPro.g:579:3: rule__Frame__RightAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Frame__RightAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFrameAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__3__Impl"


    // $ANTLR start "rule__Frame__Group__4"
    // InternalGuiPro.g:587:1: rule__Frame__Group__4 : rule__Frame__Group__4__Impl rule__Frame__Group__5 ;
    public final void rule__Frame__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:591:1: ( rule__Frame__Group__4__Impl rule__Frame__Group__5 )
            // InternalGuiPro.g:592:2: rule__Frame__Group__4__Impl rule__Frame__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Frame__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__4"


    // $ANTLR start "rule__Frame__Group__4__Impl"
    // InternalGuiPro.g:599:1: rule__Frame__Group__4__Impl : ( '{' ) ;
    public final void rule__Frame__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:603:1: ( ( '{' ) )
            // InternalGuiPro.g:604:1: ( '{' )
            {
            // InternalGuiPro.g:604:1: ( '{' )
            // InternalGuiPro.g:605:2: '{'
            {
             before(grammarAccess.getFrameAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getFrameAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__4__Impl"


    // $ANTLR start "rule__Frame__Group__5"
    // InternalGuiPro.g:614:1: rule__Frame__Group__5 : rule__Frame__Group__5__Impl rule__Frame__Group__6 ;
    public final void rule__Frame__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:618:1: ( rule__Frame__Group__5__Impl rule__Frame__Group__6 )
            // InternalGuiPro.g:619:2: rule__Frame__Group__5__Impl rule__Frame__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Frame__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Frame__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__5"


    // $ANTLR start "rule__Frame__Group__5__Impl"
    // InternalGuiPro.g:626:1: rule__Frame__Group__5__Impl : ( ( rule__Frame__PanelsAssignment_5 )* ) ;
    public final void rule__Frame__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:630:1: ( ( ( rule__Frame__PanelsAssignment_5 )* ) )
            // InternalGuiPro.g:631:1: ( ( rule__Frame__PanelsAssignment_5 )* )
            {
            // InternalGuiPro.g:631:1: ( ( rule__Frame__PanelsAssignment_5 )* )
            // InternalGuiPro.g:632:2: ( rule__Frame__PanelsAssignment_5 )*
            {
             before(grammarAccess.getFrameAccess().getPanelsAssignment_5()); 
            // InternalGuiPro.g:633:2: ( rule__Frame__PanelsAssignment_5 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>=13 && LA7_0<=14)) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalGuiPro.g:633:3: rule__Frame__PanelsAssignment_5
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Frame__PanelsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getFrameAccess().getPanelsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__5__Impl"


    // $ANTLR start "rule__Frame__Group__6"
    // InternalGuiPro.g:641:1: rule__Frame__Group__6 : rule__Frame__Group__6__Impl ;
    public final void rule__Frame__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:645:1: ( rule__Frame__Group__6__Impl )
            // InternalGuiPro.g:646:2: rule__Frame__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Frame__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__6"


    // $ANTLR start "rule__Frame__Group__6__Impl"
    // InternalGuiPro.g:652:1: rule__Frame__Group__6__Impl : ( '}' ) ;
    public final void rule__Frame__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:656:1: ( ( '}' ) )
            // InternalGuiPro.g:657:1: ( '}' )
            {
            // InternalGuiPro.g:657:1: ( '}' )
            // InternalGuiPro.g:658:2: '}'
            {
             before(grammarAccess.getFrameAccess().getRightCurlyBracketKeyword_6()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getFrameAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__Group__6__Impl"


    // $ANTLR start "rule__Panel__Group__0"
    // InternalGuiPro.g:668:1: rule__Panel__Group__0 : rule__Panel__Group__0__Impl rule__Panel__Group__1 ;
    public final void rule__Panel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:672:1: ( rule__Panel__Group__0__Impl rule__Panel__Group__1 )
            // InternalGuiPro.g:673:2: rule__Panel__Group__0__Impl rule__Panel__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Panel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__0"


    // $ANTLR start "rule__Panel__Group__0__Impl"
    // InternalGuiPro.g:680:1: rule__Panel__Group__0__Impl : ( ( rule__Panel__LeftAssignment_0 ) ) ;
    public final void rule__Panel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:684:1: ( ( ( rule__Panel__LeftAssignment_0 ) ) )
            // InternalGuiPro.g:685:1: ( ( rule__Panel__LeftAssignment_0 ) )
            {
            // InternalGuiPro.g:685:1: ( ( rule__Panel__LeftAssignment_0 ) )
            // InternalGuiPro.g:686:2: ( rule__Panel__LeftAssignment_0 )
            {
             before(grammarAccess.getPanelAccess().getLeftAssignment_0()); 
            // InternalGuiPro.g:687:2: ( rule__Panel__LeftAssignment_0 )
            // InternalGuiPro.g:687:3: rule__Panel__LeftAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Panel__LeftAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPanelAccess().getLeftAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__0__Impl"


    // $ANTLR start "rule__Panel__Group__1"
    // InternalGuiPro.g:695:1: rule__Panel__Group__1 : rule__Panel__Group__1__Impl rule__Panel__Group__2 ;
    public final void rule__Panel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:699:1: ( rule__Panel__Group__1__Impl rule__Panel__Group__2 )
            // InternalGuiPro.g:700:2: rule__Panel__Group__1__Impl rule__Panel__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__Panel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__1"


    // $ANTLR start "rule__Panel__Group__1__Impl"
    // InternalGuiPro.g:707:1: rule__Panel__Group__1__Impl : ( ( rule__Panel__NameAssignment_1 ) ) ;
    public final void rule__Panel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:711:1: ( ( ( rule__Panel__NameAssignment_1 ) ) )
            // InternalGuiPro.g:712:1: ( ( rule__Panel__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:712:1: ( ( rule__Panel__NameAssignment_1 ) )
            // InternalGuiPro.g:713:2: ( rule__Panel__NameAssignment_1 )
            {
             before(grammarAccess.getPanelAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:714:2: ( rule__Panel__NameAssignment_1 )
            // InternalGuiPro.g:714:3: rule__Panel__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Panel__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPanelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__1__Impl"


    // $ANTLR start "rule__Panel__Group__2"
    // InternalGuiPro.g:722:1: rule__Panel__Group__2 : rule__Panel__Group__2__Impl rule__Panel__Group__3 ;
    public final void rule__Panel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:726:1: ( rule__Panel__Group__2__Impl rule__Panel__Group__3 )
            // InternalGuiPro.g:727:2: rule__Panel__Group__2__Impl rule__Panel__Group__3
            {
            pushFollow(FOLLOW_7);
            rule__Panel__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panel__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__2"


    // $ANTLR start "rule__Panel__Group__2__Impl"
    // InternalGuiPro.g:734:1: rule__Panel__Group__2__Impl : ( ( rule__Panel__RightAssignment_2 )? ) ;
    public final void rule__Panel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:738:1: ( ( ( rule__Panel__RightAssignment_2 )? ) )
            // InternalGuiPro.g:739:1: ( ( rule__Panel__RightAssignment_2 )? )
            {
            // InternalGuiPro.g:739:1: ( ( rule__Panel__RightAssignment_2 )? )
            // InternalGuiPro.g:740:2: ( rule__Panel__RightAssignment_2 )?
            {
             before(grammarAccess.getPanelAccess().getRightAssignment_2()); 
            // InternalGuiPro.g:741:2: ( rule__Panel__RightAssignment_2 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==22) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalGuiPro.g:741:3: rule__Panel__RightAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Panel__RightAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPanelAccess().getRightAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__2__Impl"


    // $ANTLR start "rule__Panel__Group__3"
    // InternalGuiPro.g:749:1: rule__Panel__Group__3 : rule__Panel__Group__3__Impl rule__Panel__Group__4 ;
    public final void rule__Panel__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:753:1: ( rule__Panel__Group__3__Impl rule__Panel__Group__4 )
            // InternalGuiPro.g:754:2: rule__Panel__Group__3__Impl rule__Panel__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__Panel__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panel__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__3"


    // $ANTLR start "rule__Panel__Group__3__Impl"
    // InternalGuiPro.g:761:1: rule__Panel__Group__3__Impl : ( '{' ) ;
    public final void rule__Panel__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:765:1: ( ( '{' ) )
            // InternalGuiPro.g:766:1: ( '{' )
            {
            // InternalGuiPro.g:766:1: ( '{' )
            // InternalGuiPro.g:767:2: '{'
            {
             before(grammarAccess.getPanelAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getPanelAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__3__Impl"


    // $ANTLR start "rule__Panel__Group__4"
    // InternalGuiPro.g:776:1: rule__Panel__Group__4 : rule__Panel__Group__4__Impl rule__Panel__Group__5 ;
    public final void rule__Panel__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:780:1: ( rule__Panel__Group__4__Impl rule__Panel__Group__5 )
            // InternalGuiPro.g:781:2: rule__Panel__Group__4__Impl rule__Panel__Group__5
            {
            pushFollow(FOLLOW_8);
            rule__Panel__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panel__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__4"


    // $ANTLR start "rule__Panel__Group__4__Impl"
    // InternalGuiPro.g:788:1: rule__Panel__Group__4__Impl : ( ( rule__Panel__Alternatives_4 )* ) ;
    public final void rule__Panel__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:792:1: ( ( ( rule__Panel__Alternatives_4 )* ) )
            // InternalGuiPro.g:793:1: ( ( rule__Panel__Alternatives_4 )* )
            {
            // InternalGuiPro.g:793:1: ( ( rule__Panel__Alternatives_4 )* )
            // InternalGuiPro.g:794:2: ( rule__Panel__Alternatives_4 )*
            {
             before(grammarAccess.getPanelAccess().getAlternatives_4()); 
            // InternalGuiPro.g:795:2: ( rule__Panel__Alternatives_4 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>=13 && LA9_0<=14)||(LA9_0>=17 && LA9_0<=21)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalGuiPro.g:795:3: rule__Panel__Alternatives_4
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Panel__Alternatives_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getPanelAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__4__Impl"


    // $ANTLR start "rule__Panel__Group__5"
    // InternalGuiPro.g:803:1: rule__Panel__Group__5 : rule__Panel__Group__5__Impl ;
    public final void rule__Panel__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:807:1: ( rule__Panel__Group__5__Impl )
            // InternalGuiPro.g:808:2: rule__Panel__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Panel__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__5"


    // $ANTLR start "rule__Panel__Group__5__Impl"
    // InternalGuiPro.g:814:1: rule__Panel__Group__5__Impl : ( '}' ) ;
    public final void rule__Panel__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:818:1: ( ( '}' ) )
            // InternalGuiPro.g:819:1: ( '}' )
            {
            // InternalGuiPro.g:819:1: ( '}' )
            // InternalGuiPro.g:820:2: '}'
            {
             before(grammarAccess.getPanelAccess().getRightCurlyBracketKeyword_5()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getPanelAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__Group__5__Impl"


    // $ANTLR start "rule__Button__Group__0"
    // InternalGuiPro.g:830:1: rule__Button__Group__0 : rule__Button__Group__0__Impl rule__Button__Group__1 ;
    public final void rule__Button__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:834:1: ( rule__Button__Group__0__Impl rule__Button__Group__1 )
            // InternalGuiPro.g:835:2: rule__Button__Group__0__Impl rule__Button__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Button__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Button__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0"


    // $ANTLR start "rule__Button__Group__0__Impl"
    // InternalGuiPro.g:842:1: rule__Button__Group__0__Impl : ( 'button' ) ;
    public final void rule__Button__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:846:1: ( ( 'button' ) )
            // InternalGuiPro.g:847:1: ( 'button' )
            {
            // InternalGuiPro.g:847:1: ( 'button' )
            // InternalGuiPro.g:848:2: 'button'
            {
             before(grammarAccess.getButtonAccess().getButtonKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getButtonAccess().getButtonKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0__Impl"


    // $ANTLR start "rule__Button__Group__1"
    // InternalGuiPro.g:857:1: rule__Button__Group__1 : rule__Button__Group__1__Impl rule__Button__Group__2 ;
    public final void rule__Button__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:861:1: ( rule__Button__Group__1__Impl rule__Button__Group__2 )
            // InternalGuiPro.g:862:2: rule__Button__Group__1__Impl rule__Button__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Button__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Button__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1"


    // $ANTLR start "rule__Button__Group__1__Impl"
    // InternalGuiPro.g:869:1: rule__Button__Group__1__Impl : ( ( rule__Button__NameAssignment_1 ) ) ;
    public final void rule__Button__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:873:1: ( ( ( rule__Button__NameAssignment_1 ) ) )
            // InternalGuiPro.g:874:1: ( ( rule__Button__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:874:1: ( ( rule__Button__NameAssignment_1 ) )
            // InternalGuiPro.g:875:2: ( rule__Button__NameAssignment_1 )
            {
             before(grammarAccess.getButtonAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:876:2: ( rule__Button__NameAssignment_1 )
            // InternalGuiPro.g:876:3: rule__Button__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Button__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1__Impl"


    // $ANTLR start "rule__Button__Group__2"
    // InternalGuiPro.g:884:1: rule__Button__Group__2 : rule__Button__Group__2__Impl rule__Button__Group__3 ;
    public final void rule__Button__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:888:1: ( rule__Button__Group__2__Impl rule__Button__Group__3 )
            // InternalGuiPro.g:889:2: rule__Button__Group__2__Impl rule__Button__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Button__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Button__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__2"


    // $ANTLR start "rule__Button__Group__2__Impl"
    // InternalGuiPro.g:896:1: rule__Button__Group__2__Impl : ( ( rule__Button__CenterAssignment_2 )? ) ;
    public final void rule__Button__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:900:1: ( ( ( rule__Button__CenterAssignment_2 )? ) )
            // InternalGuiPro.g:901:1: ( ( rule__Button__CenterAssignment_2 )? )
            {
            // InternalGuiPro.g:901:1: ( ( rule__Button__CenterAssignment_2 )? )
            // InternalGuiPro.g:902:2: ( rule__Button__CenterAssignment_2 )?
            {
             before(grammarAccess.getButtonAccess().getCenterAssignment_2()); 
            // InternalGuiPro.g:903:2: ( rule__Button__CenterAssignment_2 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==25) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalGuiPro.g:903:3: rule__Button__CenterAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Button__CenterAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getButtonAccess().getCenterAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__2__Impl"


    // $ANTLR start "rule__Button__Group__3"
    // InternalGuiPro.g:911:1: rule__Button__Group__3 : rule__Button__Group__3__Impl ;
    public final void rule__Button__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:915:1: ( rule__Button__Group__3__Impl )
            // InternalGuiPro.g:916:2: rule__Button__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Button__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__3"


    // $ANTLR start "rule__Button__Group__3__Impl"
    // InternalGuiPro.g:922:1: rule__Button__Group__3__Impl : ( ( rule__Button__RightAssignment_3 )? ) ;
    public final void rule__Button__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:926:1: ( ( ( rule__Button__RightAssignment_3 )? ) )
            // InternalGuiPro.g:927:1: ( ( rule__Button__RightAssignment_3 )? )
            {
            // InternalGuiPro.g:927:1: ( ( rule__Button__RightAssignment_3 )? )
            // InternalGuiPro.g:928:2: ( rule__Button__RightAssignment_3 )?
            {
             before(grammarAccess.getButtonAccess().getRightAssignment_3()); 
            // InternalGuiPro.g:929:2: ( rule__Button__RightAssignment_3 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==22) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalGuiPro.g:929:3: rule__Button__RightAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Button__RightAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getButtonAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__3__Impl"


    // $ANTLR start "rule__TextField__Group__0"
    // InternalGuiPro.g:938:1: rule__TextField__Group__0 : rule__TextField__Group__0__Impl rule__TextField__Group__1 ;
    public final void rule__TextField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:942:1: ( rule__TextField__Group__0__Impl rule__TextField__Group__1 )
            // InternalGuiPro.g:943:2: rule__TextField__Group__0__Impl rule__TextField__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__TextField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TextField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__0"


    // $ANTLR start "rule__TextField__Group__0__Impl"
    // InternalGuiPro.g:950:1: rule__TextField__Group__0__Impl : ( 'textField' ) ;
    public final void rule__TextField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:954:1: ( ( 'textField' ) )
            // InternalGuiPro.g:955:1: ( 'textField' )
            {
            // InternalGuiPro.g:955:1: ( 'textField' )
            // InternalGuiPro.g:956:2: 'textField'
            {
             before(grammarAccess.getTextFieldAccess().getTextFieldKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getTextFieldAccess().getTextFieldKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__0__Impl"


    // $ANTLR start "rule__TextField__Group__1"
    // InternalGuiPro.g:965:1: rule__TextField__Group__1 : rule__TextField__Group__1__Impl rule__TextField__Group__2 ;
    public final void rule__TextField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:969:1: ( rule__TextField__Group__1__Impl rule__TextField__Group__2 )
            // InternalGuiPro.g:970:2: rule__TextField__Group__1__Impl rule__TextField__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__TextField__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TextField__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__1"


    // $ANTLR start "rule__TextField__Group__1__Impl"
    // InternalGuiPro.g:977:1: rule__TextField__Group__1__Impl : ( ( rule__TextField__NameAssignment_1 ) ) ;
    public final void rule__TextField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:981:1: ( ( ( rule__TextField__NameAssignment_1 ) ) )
            // InternalGuiPro.g:982:1: ( ( rule__TextField__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:982:1: ( ( rule__TextField__NameAssignment_1 ) )
            // InternalGuiPro.g:983:2: ( rule__TextField__NameAssignment_1 )
            {
             before(grammarAccess.getTextFieldAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:984:2: ( rule__TextField__NameAssignment_1 )
            // InternalGuiPro.g:984:3: rule__TextField__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__TextField__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTextFieldAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__1__Impl"


    // $ANTLR start "rule__TextField__Group__2"
    // InternalGuiPro.g:992:1: rule__TextField__Group__2 : rule__TextField__Group__2__Impl rule__TextField__Group__3 ;
    public final void rule__TextField__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:996:1: ( rule__TextField__Group__2__Impl rule__TextField__Group__3 )
            // InternalGuiPro.g:997:2: rule__TextField__Group__2__Impl rule__TextField__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__TextField__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TextField__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__2"


    // $ANTLR start "rule__TextField__Group__2__Impl"
    // InternalGuiPro.g:1004:1: rule__TextField__Group__2__Impl : ( ( rule__TextField__CenterAssignment_2 )? ) ;
    public final void rule__TextField__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1008:1: ( ( ( rule__TextField__CenterAssignment_2 )? ) )
            // InternalGuiPro.g:1009:1: ( ( rule__TextField__CenterAssignment_2 )? )
            {
            // InternalGuiPro.g:1009:1: ( ( rule__TextField__CenterAssignment_2 )? )
            // InternalGuiPro.g:1010:2: ( rule__TextField__CenterAssignment_2 )?
            {
             before(grammarAccess.getTextFieldAccess().getCenterAssignment_2()); 
            // InternalGuiPro.g:1011:2: ( rule__TextField__CenterAssignment_2 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==25) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalGuiPro.g:1011:3: rule__TextField__CenterAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__TextField__CenterAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTextFieldAccess().getCenterAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__2__Impl"


    // $ANTLR start "rule__TextField__Group__3"
    // InternalGuiPro.g:1019:1: rule__TextField__Group__3 : rule__TextField__Group__3__Impl ;
    public final void rule__TextField__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1023:1: ( rule__TextField__Group__3__Impl )
            // InternalGuiPro.g:1024:2: rule__TextField__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TextField__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__3"


    // $ANTLR start "rule__TextField__Group__3__Impl"
    // InternalGuiPro.g:1030:1: rule__TextField__Group__3__Impl : ( ( rule__TextField__RightAssignment_3 )? ) ;
    public final void rule__TextField__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1034:1: ( ( ( rule__TextField__RightAssignment_3 )? ) )
            // InternalGuiPro.g:1035:1: ( ( rule__TextField__RightAssignment_3 )? )
            {
            // InternalGuiPro.g:1035:1: ( ( rule__TextField__RightAssignment_3 )? )
            // InternalGuiPro.g:1036:2: ( rule__TextField__RightAssignment_3 )?
            {
             before(grammarAccess.getTextFieldAccess().getRightAssignment_3()); 
            // InternalGuiPro.g:1037:2: ( rule__TextField__RightAssignment_3 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==22) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalGuiPro.g:1037:3: rule__TextField__RightAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__TextField__RightAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTextFieldAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__Group__3__Impl"


    // $ANTLR start "rule__CheckBox__Group__0"
    // InternalGuiPro.g:1046:1: rule__CheckBox__Group__0 : rule__CheckBox__Group__0__Impl rule__CheckBox__Group__1 ;
    public final void rule__CheckBox__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1050:1: ( rule__CheckBox__Group__0__Impl rule__CheckBox__Group__1 )
            // InternalGuiPro.g:1051:2: rule__CheckBox__Group__0__Impl rule__CheckBox__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__CheckBox__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CheckBox__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__0"


    // $ANTLR start "rule__CheckBox__Group__0__Impl"
    // InternalGuiPro.g:1058:1: rule__CheckBox__Group__0__Impl : ( 'checkBox' ) ;
    public final void rule__CheckBox__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1062:1: ( ( 'checkBox' ) )
            // InternalGuiPro.g:1063:1: ( 'checkBox' )
            {
            // InternalGuiPro.g:1063:1: ( 'checkBox' )
            // InternalGuiPro.g:1064:2: 'checkBox'
            {
             before(grammarAccess.getCheckBoxAccess().getCheckBoxKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getCheckBoxAccess().getCheckBoxKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__0__Impl"


    // $ANTLR start "rule__CheckBox__Group__1"
    // InternalGuiPro.g:1073:1: rule__CheckBox__Group__1 : rule__CheckBox__Group__1__Impl rule__CheckBox__Group__2 ;
    public final void rule__CheckBox__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1077:1: ( rule__CheckBox__Group__1__Impl rule__CheckBox__Group__2 )
            // InternalGuiPro.g:1078:2: rule__CheckBox__Group__1__Impl rule__CheckBox__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__CheckBox__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CheckBox__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__1"


    // $ANTLR start "rule__CheckBox__Group__1__Impl"
    // InternalGuiPro.g:1085:1: rule__CheckBox__Group__1__Impl : ( ( rule__CheckBox__NameAssignment_1 ) ) ;
    public final void rule__CheckBox__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1089:1: ( ( ( rule__CheckBox__NameAssignment_1 ) ) )
            // InternalGuiPro.g:1090:1: ( ( rule__CheckBox__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:1090:1: ( ( rule__CheckBox__NameAssignment_1 ) )
            // InternalGuiPro.g:1091:2: ( rule__CheckBox__NameAssignment_1 )
            {
             before(grammarAccess.getCheckBoxAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:1092:2: ( rule__CheckBox__NameAssignment_1 )
            // InternalGuiPro.g:1092:3: rule__CheckBox__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__CheckBox__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCheckBoxAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__1__Impl"


    // $ANTLR start "rule__CheckBox__Group__2"
    // InternalGuiPro.g:1100:1: rule__CheckBox__Group__2 : rule__CheckBox__Group__2__Impl rule__CheckBox__Group__3 ;
    public final void rule__CheckBox__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1104:1: ( rule__CheckBox__Group__2__Impl rule__CheckBox__Group__3 )
            // InternalGuiPro.g:1105:2: rule__CheckBox__Group__2__Impl rule__CheckBox__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__CheckBox__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CheckBox__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__2"


    // $ANTLR start "rule__CheckBox__Group__2__Impl"
    // InternalGuiPro.g:1112:1: rule__CheckBox__Group__2__Impl : ( ( rule__CheckBox__CenterAssignment_2 )? ) ;
    public final void rule__CheckBox__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1116:1: ( ( ( rule__CheckBox__CenterAssignment_2 )? ) )
            // InternalGuiPro.g:1117:1: ( ( rule__CheckBox__CenterAssignment_2 )? )
            {
            // InternalGuiPro.g:1117:1: ( ( rule__CheckBox__CenterAssignment_2 )? )
            // InternalGuiPro.g:1118:2: ( rule__CheckBox__CenterAssignment_2 )?
            {
             before(grammarAccess.getCheckBoxAccess().getCenterAssignment_2()); 
            // InternalGuiPro.g:1119:2: ( rule__CheckBox__CenterAssignment_2 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==25) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalGuiPro.g:1119:3: rule__CheckBox__CenterAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__CheckBox__CenterAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCheckBoxAccess().getCenterAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__2__Impl"


    // $ANTLR start "rule__CheckBox__Group__3"
    // InternalGuiPro.g:1127:1: rule__CheckBox__Group__3 : rule__CheckBox__Group__3__Impl ;
    public final void rule__CheckBox__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1131:1: ( rule__CheckBox__Group__3__Impl )
            // InternalGuiPro.g:1132:2: rule__CheckBox__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CheckBox__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__3"


    // $ANTLR start "rule__CheckBox__Group__3__Impl"
    // InternalGuiPro.g:1138:1: rule__CheckBox__Group__3__Impl : ( ( rule__CheckBox__RightAssignment_3 )? ) ;
    public final void rule__CheckBox__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1142:1: ( ( ( rule__CheckBox__RightAssignment_3 )? ) )
            // InternalGuiPro.g:1143:1: ( ( rule__CheckBox__RightAssignment_3 )? )
            {
            // InternalGuiPro.g:1143:1: ( ( rule__CheckBox__RightAssignment_3 )? )
            // InternalGuiPro.g:1144:2: ( rule__CheckBox__RightAssignment_3 )?
            {
             before(grammarAccess.getCheckBoxAccess().getRightAssignment_3()); 
            // InternalGuiPro.g:1145:2: ( rule__CheckBox__RightAssignment_3 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==22) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalGuiPro.g:1145:3: rule__CheckBox__RightAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__CheckBox__RightAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCheckBoxAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__Group__3__Impl"


    // $ANTLR start "rule__Label__Group__0"
    // InternalGuiPro.g:1154:1: rule__Label__Group__0 : rule__Label__Group__0__Impl rule__Label__Group__1 ;
    public final void rule__Label__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1158:1: ( rule__Label__Group__0__Impl rule__Label__Group__1 )
            // InternalGuiPro.g:1159:2: rule__Label__Group__0__Impl rule__Label__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Label__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Label__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0"


    // $ANTLR start "rule__Label__Group__0__Impl"
    // InternalGuiPro.g:1166:1: rule__Label__Group__0__Impl : ( 'label' ) ;
    public final void rule__Label__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1170:1: ( ( 'label' ) )
            // InternalGuiPro.g:1171:1: ( 'label' )
            {
            // InternalGuiPro.g:1171:1: ( 'label' )
            // InternalGuiPro.g:1172:2: 'label'
            {
             before(grammarAccess.getLabelAccess().getLabelKeyword_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getLabelAccess().getLabelKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0__Impl"


    // $ANTLR start "rule__Label__Group__1"
    // InternalGuiPro.g:1181:1: rule__Label__Group__1 : rule__Label__Group__1__Impl rule__Label__Group__2 ;
    public final void rule__Label__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1185:1: ( rule__Label__Group__1__Impl rule__Label__Group__2 )
            // InternalGuiPro.g:1186:2: rule__Label__Group__1__Impl rule__Label__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Label__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Label__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1"


    // $ANTLR start "rule__Label__Group__1__Impl"
    // InternalGuiPro.g:1193:1: rule__Label__Group__1__Impl : ( ( rule__Label__NameAssignment_1 ) ) ;
    public final void rule__Label__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1197:1: ( ( ( rule__Label__NameAssignment_1 ) ) )
            // InternalGuiPro.g:1198:1: ( ( rule__Label__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:1198:1: ( ( rule__Label__NameAssignment_1 ) )
            // InternalGuiPro.g:1199:2: ( rule__Label__NameAssignment_1 )
            {
             before(grammarAccess.getLabelAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:1200:2: ( rule__Label__NameAssignment_1 )
            // InternalGuiPro.g:1200:3: rule__Label__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Label__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1__Impl"


    // $ANTLR start "rule__Label__Group__2"
    // InternalGuiPro.g:1208:1: rule__Label__Group__2 : rule__Label__Group__2__Impl rule__Label__Group__3 ;
    public final void rule__Label__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1212:1: ( rule__Label__Group__2__Impl rule__Label__Group__3 )
            // InternalGuiPro.g:1213:2: rule__Label__Group__2__Impl rule__Label__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Label__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Label__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2"


    // $ANTLR start "rule__Label__Group__2__Impl"
    // InternalGuiPro.g:1220:1: rule__Label__Group__2__Impl : ( ( rule__Label__CenterAssignment_2 )? ) ;
    public final void rule__Label__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1224:1: ( ( ( rule__Label__CenterAssignment_2 )? ) )
            // InternalGuiPro.g:1225:1: ( ( rule__Label__CenterAssignment_2 )? )
            {
            // InternalGuiPro.g:1225:1: ( ( rule__Label__CenterAssignment_2 )? )
            // InternalGuiPro.g:1226:2: ( rule__Label__CenterAssignment_2 )?
            {
             before(grammarAccess.getLabelAccess().getCenterAssignment_2()); 
            // InternalGuiPro.g:1227:2: ( rule__Label__CenterAssignment_2 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==25) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalGuiPro.g:1227:3: rule__Label__CenterAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Label__CenterAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLabelAccess().getCenterAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2__Impl"


    // $ANTLR start "rule__Label__Group__3"
    // InternalGuiPro.g:1235:1: rule__Label__Group__3 : rule__Label__Group__3__Impl ;
    public final void rule__Label__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1239:1: ( rule__Label__Group__3__Impl )
            // InternalGuiPro.g:1240:2: rule__Label__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Label__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__3"


    // $ANTLR start "rule__Label__Group__3__Impl"
    // InternalGuiPro.g:1246:1: rule__Label__Group__3__Impl : ( ( rule__Label__RightAssignment_3 )? ) ;
    public final void rule__Label__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1250:1: ( ( ( rule__Label__RightAssignment_3 )? ) )
            // InternalGuiPro.g:1251:1: ( ( rule__Label__RightAssignment_3 )? )
            {
            // InternalGuiPro.g:1251:1: ( ( rule__Label__RightAssignment_3 )? )
            // InternalGuiPro.g:1252:2: ( rule__Label__RightAssignment_3 )?
            {
             before(grammarAccess.getLabelAccess().getRightAssignment_3()); 
            // InternalGuiPro.g:1253:2: ( rule__Label__RightAssignment_3 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==22) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalGuiPro.g:1253:3: rule__Label__RightAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Label__RightAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLabelAccess().getRightAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__3__Impl"


    // $ANTLR start "rule__ListView__Group__0"
    // InternalGuiPro.g:1262:1: rule__ListView__Group__0 : rule__ListView__Group__0__Impl rule__ListView__Group__1 ;
    public final void rule__ListView__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1266:1: ( rule__ListView__Group__0__Impl rule__ListView__Group__1 )
            // InternalGuiPro.g:1267:2: rule__ListView__Group__0__Impl rule__ListView__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__ListView__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListView__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__0"


    // $ANTLR start "rule__ListView__Group__0__Impl"
    // InternalGuiPro.g:1274:1: rule__ListView__Group__0__Impl : ( 'listView' ) ;
    public final void rule__ListView__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1278:1: ( ( 'listView' ) )
            // InternalGuiPro.g:1279:1: ( 'listView' )
            {
            // InternalGuiPro.g:1279:1: ( 'listView' )
            // InternalGuiPro.g:1280:2: 'listView'
            {
             before(grammarAccess.getListViewAccess().getListViewKeyword_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getListViewAccess().getListViewKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__0__Impl"


    // $ANTLR start "rule__ListView__Group__1"
    // InternalGuiPro.g:1289:1: rule__ListView__Group__1 : rule__ListView__Group__1__Impl rule__ListView__Group__2 ;
    public final void rule__ListView__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1293:1: ( rule__ListView__Group__1__Impl rule__ListView__Group__2 )
            // InternalGuiPro.g:1294:2: rule__ListView__Group__1__Impl rule__ListView__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__ListView__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListView__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__1"


    // $ANTLR start "rule__ListView__Group__1__Impl"
    // InternalGuiPro.g:1301:1: rule__ListView__Group__1__Impl : ( ( rule__ListView__NameAssignment_1 ) ) ;
    public final void rule__ListView__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1305:1: ( ( ( rule__ListView__NameAssignment_1 ) ) )
            // InternalGuiPro.g:1306:1: ( ( rule__ListView__NameAssignment_1 ) )
            {
            // InternalGuiPro.g:1306:1: ( ( rule__ListView__NameAssignment_1 ) )
            // InternalGuiPro.g:1307:2: ( rule__ListView__NameAssignment_1 )
            {
             before(grammarAccess.getListViewAccess().getNameAssignment_1()); 
            // InternalGuiPro.g:1308:2: ( rule__ListView__NameAssignment_1 )
            // InternalGuiPro.g:1308:3: rule__ListView__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ListView__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getListViewAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__1__Impl"


    // $ANTLR start "rule__ListView__Group__2"
    // InternalGuiPro.g:1316:1: rule__ListView__Group__2 : rule__ListView__Group__2__Impl ;
    public final void rule__ListView__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1320:1: ( rule__ListView__Group__2__Impl )
            // InternalGuiPro.g:1321:2: rule__ListView__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListView__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__2"


    // $ANTLR start "rule__ListView__Group__2__Impl"
    // InternalGuiPro.g:1327:1: rule__ListView__Group__2__Impl : ( ( rule__ListView__RightAssignment_2 )? ) ;
    public final void rule__ListView__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1331:1: ( ( ( rule__ListView__RightAssignment_2 )? ) )
            // InternalGuiPro.g:1332:1: ( ( rule__ListView__RightAssignment_2 )? )
            {
            // InternalGuiPro.g:1332:1: ( ( rule__ListView__RightAssignment_2 )? )
            // InternalGuiPro.g:1333:2: ( rule__ListView__RightAssignment_2 )?
            {
             before(grammarAccess.getListViewAccess().getRightAssignment_2()); 
            // InternalGuiPro.g:1334:2: ( rule__ListView__RightAssignment_2 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==22) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalGuiPro.g:1334:3: rule__ListView__RightAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__ListView__RightAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getListViewAccess().getRightAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__Group__2__Impl"


    // $ANTLR start "rule__Size__Group__0"
    // InternalGuiPro.g:1343:1: rule__Size__Group__0 : rule__Size__Group__0__Impl rule__Size__Group__1 ;
    public final void rule__Size__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1347:1: ( rule__Size__Group__0__Impl rule__Size__Group__1 )
            // InternalGuiPro.g:1348:2: rule__Size__Group__0__Impl rule__Size__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Size__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Size__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__0"


    // $ANTLR start "rule__Size__Group__0__Impl"
    // InternalGuiPro.g:1355:1: rule__Size__Group__0__Impl : ( '(' ) ;
    public final void rule__Size__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1359:1: ( ( '(' ) )
            // InternalGuiPro.g:1360:1: ( '(' )
            {
            // InternalGuiPro.g:1360:1: ( '(' )
            // InternalGuiPro.g:1361:2: '('
            {
             before(grammarAccess.getSizeAccess().getLeftParenthesisKeyword_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getSizeAccess().getLeftParenthesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__0__Impl"


    // $ANTLR start "rule__Size__Group__1"
    // InternalGuiPro.g:1370:1: rule__Size__Group__1 : rule__Size__Group__1__Impl rule__Size__Group__2 ;
    public final void rule__Size__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1374:1: ( rule__Size__Group__1__Impl rule__Size__Group__2 )
            // InternalGuiPro.g:1375:2: rule__Size__Group__1__Impl rule__Size__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__Size__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Size__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__1"


    // $ANTLR start "rule__Size__Group__1__Impl"
    // InternalGuiPro.g:1382:1: rule__Size__Group__1__Impl : ( ( rule__Size__XAssignment_1 ) ) ;
    public final void rule__Size__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1386:1: ( ( ( rule__Size__XAssignment_1 ) ) )
            // InternalGuiPro.g:1387:1: ( ( rule__Size__XAssignment_1 ) )
            {
            // InternalGuiPro.g:1387:1: ( ( rule__Size__XAssignment_1 ) )
            // InternalGuiPro.g:1388:2: ( rule__Size__XAssignment_1 )
            {
             before(grammarAccess.getSizeAccess().getXAssignment_1()); 
            // InternalGuiPro.g:1389:2: ( rule__Size__XAssignment_1 )
            // InternalGuiPro.g:1389:3: rule__Size__XAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Size__XAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getXAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__1__Impl"


    // $ANTLR start "rule__Size__Group__2"
    // InternalGuiPro.g:1397:1: rule__Size__Group__2 : rule__Size__Group__2__Impl rule__Size__Group__3 ;
    public final void rule__Size__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1401:1: ( rule__Size__Group__2__Impl rule__Size__Group__3 )
            // InternalGuiPro.g:1402:2: rule__Size__Group__2__Impl rule__Size__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__Size__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Size__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__2"


    // $ANTLR start "rule__Size__Group__2__Impl"
    // InternalGuiPro.g:1409:1: rule__Size__Group__2__Impl : ( ',' ) ;
    public final void rule__Size__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1413:1: ( ( ',' ) )
            // InternalGuiPro.g:1414:1: ( ',' )
            {
            // InternalGuiPro.g:1414:1: ( ',' )
            // InternalGuiPro.g:1415:2: ','
            {
             before(grammarAccess.getSizeAccess().getCommaKeyword_2()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getSizeAccess().getCommaKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__2__Impl"


    // $ANTLR start "rule__Size__Group__3"
    // InternalGuiPro.g:1424:1: rule__Size__Group__3 : rule__Size__Group__3__Impl rule__Size__Group__4 ;
    public final void rule__Size__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1428:1: ( rule__Size__Group__3__Impl rule__Size__Group__4 )
            // InternalGuiPro.g:1429:2: rule__Size__Group__3__Impl rule__Size__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__Size__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Size__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__3"


    // $ANTLR start "rule__Size__Group__3__Impl"
    // InternalGuiPro.g:1436:1: rule__Size__Group__3__Impl : ( ( rule__Size__YAssignment_3 ) ) ;
    public final void rule__Size__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1440:1: ( ( ( rule__Size__YAssignment_3 ) ) )
            // InternalGuiPro.g:1441:1: ( ( rule__Size__YAssignment_3 ) )
            {
            // InternalGuiPro.g:1441:1: ( ( rule__Size__YAssignment_3 ) )
            // InternalGuiPro.g:1442:2: ( rule__Size__YAssignment_3 )
            {
             before(grammarAccess.getSizeAccess().getYAssignment_3()); 
            // InternalGuiPro.g:1443:2: ( rule__Size__YAssignment_3 )
            // InternalGuiPro.g:1443:3: rule__Size__YAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Size__YAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getYAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__3__Impl"


    // $ANTLR start "rule__Size__Group__4"
    // InternalGuiPro.g:1451:1: rule__Size__Group__4 : rule__Size__Group__4__Impl ;
    public final void rule__Size__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1455:1: ( rule__Size__Group__4__Impl )
            // InternalGuiPro.g:1456:2: rule__Size__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Size__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__4"


    // $ANTLR start "rule__Size__Group__4__Impl"
    // InternalGuiPro.g:1462:1: rule__Size__Group__4__Impl : ( ')' ) ;
    public final void rule__Size__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1466:1: ( ( ')' ) )
            // InternalGuiPro.g:1467:1: ( ')' )
            {
            // InternalGuiPro.g:1467:1: ( ')' )
            // InternalGuiPro.g:1468:2: ')'
            {
             before(grammarAccess.getSizeAccess().getRightParenthesisKeyword_4()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getSizeAccess().getRightParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__4__Impl"


    // $ANTLR start "rule__Text__Group__0"
    // InternalGuiPro.g:1478:1: rule__Text__Group__0 : rule__Text__Group__0__Impl rule__Text__Group__1 ;
    public final void rule__Text__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1482:1: ( rule__Text__Group__0__Impl rule__Text__Group__1 )
            // InternalGuiPro.g:1483:2: rule__Text__Group__0__Impl rule__Text__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__Text__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Text__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Text__Group__0"


    // $ANTLR start "rule__Text__Group__0__Impl"
    // InternalGuiPro.g:1490:1: rule__Text__Group__0__Impl : ( ':' ) ;
    public final void rule__Text__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1494:1: ( ( ':' ) )
            // InternalGuiPro.g:1495:1: ( ':' )
            {
            // InternalGuiPro.g:1495:1: ( ':' )
            // InternalGuiPro.g:1496:2: ':'
            {
             before(grammarAccess.getTextAccess().getColonKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getTextAccess().getColonKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Text__Group__0__Impl"


    // $ANTLR start "rule__Text__Group__1"
    // InternalGuiPro.g:1505:1: rule__Text__Group__1 : rule__Text__Group__1__Impl ;
    public final void rule__Text__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1509:1: ( rule__Text__Group__1__Impl )
            // InternalGuiPro.g:1510:2: rule__Text__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Text__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Text__Group__1"


    // $ANTLR start "rule__Text__Group__1__Impl"
    // InternalGuiPro.g:1516:1: rule__Text__Group__1__Impl : ( ( rule__Text__ValueAssignment_1 ) ) ;
    public final void rule__Text__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1520:1: ( ( ( rule__Text__ValueAssignment_1 ) ) )
            // InternalGuiPro.g:1521:1: ( ( rule__Text__ValueAssignment_1 ) )
            {
            // InternalGuiPro.g:1521:1: ( ( rule__Text__ValueAssignment_1 ) )
            // InternalGuiPro.g:1522:2: ( rule__Text__ValueAssignment_1 )
            {
             before(grammarAccess.getTextAccess().getValueAssignment_1()); 
            // InternalGuiPro.g:1523:2: ( rule__Text__ValueAssignment_1 )
            // InternalGuiPro.g:1523:3: rule__Text__ValueAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Text__ValueAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTextAccess().getValueAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Text__Group__1__Impl"


    // $ANTLR start "rule__System__FramesAssignment"
    // InternalGuiPro.g:1532:1: rule__System__FramesAssignment : ( ruleFrame ) ;
    public final void rule__System__FramesAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1536:1: ( ( ruleFrame ) )
            // InternalGuiPro.g:1537:2: ( ruleFrame )
            {
            // InternalGuiPro.g:1537:2: ( ruleFrame )
            // InternalGuiPro.g:1538:3: ruleFrame
            {
             before(grammarAccess.getSystemAccess().getFramesFrameParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleFrame();

            state._fsp--;

             after(grammarAccess.getSystemAccess().getFramesFrameParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__System__FramesAssignment"


    // $ANTLR start "rule__Frame__LeftAssignment_0"
    // InternalGuiPro.g:1547:1: rule__Frame__LeftAssignment_0 : ( ( rule__Frame__LeftAlternatives_0_0 ) ) ;
    public final void rule__Frame__LeftAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1551:1: ( ( ( rule__Frame__LeftAlternatives_0_0 ) ) )
            // InternalGuiPro.g:1552:2: ( ( rule__Frame__LeftAlternatives_0_0 ) )
            {
            // InternalGuiPro.g:1552:2: ( ( rule__Frame__LeftAlternatives_0_0 ) )
            // InternalGuiPro.g:1553:3: ( rule__Frame__LeftAlternatives_0_0 )
            {
             before(grammarAccess.getFrameAccess().getLeftAlternatives_0_0()); 
            // InternalGuiPro.g:1554:3: ( rule__Frame__LeftAlternatives_0_0 )
            // InternalGuiPro.g:1554:4: rule__Frame__LeftAlternatives_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Frame__LeftAlternatives_0_0();

            state._fsp--;


            }

             after(grammarAccess.getFrameAccess().getLeftAlternatives_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__LeftAssignment_0"


    // $ANTLR start "rule__Frame__NameAssignment_1"
    // InternalGuiPro.g:1562:1: rule__Frame__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Frame__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1566:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1567:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1567:2: ( RULE_ID )
            // InternalGuiPro.g:1568:3: RULE_ID
            {
             before(grammarAccess.getFrameAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getFrameAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__NameAssignment_1"


    // $ANTLR start "rule__Frame__CenterAssignment_2"
    // InternalGuiPro.g:1577:1: rule__Frame__CenterAssignment_2 : ( ruleText ) ;
    public final void rule__Frame__CenterAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1581:1: ( ( ruleText ) )
            // InternalGuiPro.g:1582:2: ( ruleText )
            {
            // InternalGuiPro.g:1582:2: ( ruleText )
            // InternalGuiPro.g:1583:3: ruleText
            {
             before(grammarAccess.getFrameAccess().getCenterTextParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleText();

            state._fsp--;

             after(grammarAccess.getFrameAccess().getCenterTextParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__CenterAssignment_2"


    // $ANTLR start "rule__Frame__RightAssignment_3"
    // InternalGuiPro.g:1592:1: rule__Frame__RightAssignment_3 : ( ruleSize ) ;
    public final void rule__Frame__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1596:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1597:2: ( ruleSize )
            {
            // InternalGuiPro.g:1597:2: ( ruleSize )
            // InternalGuiPro.g:1598:3: ruleSize
            {
             before(grammarAccess.getFrameAccess().getRightSizeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getFrameAccess().getRightSizeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__RightAssignment_3"


    // $ANTLR start "rule__Frame__PanelsAssignment_5"
    // InternalGuiPro.g:1607:1: rule__Frame__PanelsAssignment_5 : ( rulePanel ) ;
    public final void rule__Frame__PanelsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1611:1: ( ( rulePanel ) )
            // InternalGuiPro.g:1612:2: ( rulePanel )
            {
            // InternalGuiPro.g:1612:2: ( rulePanel )
            // InternalGuiPro.g:1613:3: rulePanel
            {
             before(grammarAccess.getFrameAccess().getPanelsPanelParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            rulePanel();

            state._fsp--;

             after(grammarAccess.getFrameAccess().getPanelsPanelParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Frame__PanelsAssignment_5"


    // $ANTLR start "rule__Panel__LeftAssignment_0"
    // InternalGuiPro.g:1622:1: rule__Panel__LeftAssignment_0 : ( ( rule__Panel__LeftAlternatives_0_0 ) ) ;
    public final void rule__Panel__LeftAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1626:1: ( ( ( rule__Panel__LeftAlternatives_0_0 ) ) )
            // InternalGuiPro.g:1627:2: ( ( rule__Panel__LeftAlternatives_0_0 ) )
            {
            // InternalGuiPro.g:1627:2: ( ( rule__Panel__LeftAlternatives_0_0 ) )
            // InternalGuiPro.g:1628:3: ( rule__Panel__LeftAlternatives_0_0 )
            {
             before(grammarAccess.getPanelAccess().getLeftAlternatives_0_0()); 
            // InternalGuiPro.g:1629:3: ( rule__Panel__LeftAlternatives_0_0 )
            // InternalGuiPro.g:1629:4: rule__Panel__LeftAlternatives_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Panel__LeftAlternatives_0_0();

            state._fsp--;


            }

             after(grammarAccess.getPanelAccess().getLeftAlternatives_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__LeftAssignment_0"


    // $ANTLR start "rule__Panel__NameAssignment_1"
    // InternalGuiPro.g:1637:1: rule__Panel__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Panel__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1641:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1642:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1642:2: ( RULE_ID )
            // InternalGuiPro.g:1643:3: RULE_ID
            {
             before(grammarAccess.getPanelAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPanelAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__NameAssignment_1"


    // $ANTLR start "rule__Panel__RightAssignment_2"
    // InternalGuiPro.g:1652:1: rule__Panel__RightAssignment_2 : ( ruleSize ) ;
    public final void rule__Panel__RightAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1656:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1657:2: ( ruleSize )
            {
            // InternalGuiPro.g:1657:2: ( ruleSize )
            // InternalGuiPro.g:1658:3: ruleSize
            {
             before(grammarAccess.getPanelAccess().getRightSizeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getPanelAccess().getRightSizeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__RightAssignment_2"


    // $ANTLR start "rule__Panel__ControlsAssignment_4_0"
    // InternalGuiPro.g:1667:1: rule__Panel__ControlsAssignment_4_0 : ( ruleControl ) ;
    public final void rule__Panel__ControlsAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1671:1: ( ( ruleControl ) )
            // InternalGuiPro.g:1672:2: ( ruleControl )
            {
            // InternalGuiPro.g:1672:2: ( ruleControl )
            // InternalGuiPro.g:1673:3: ruleControl
            {
             before(grammarAccess.getPanelAccess().getControlsControlParserRuleCall_4_0_0()); 
            pushFollow(FOLLOW_2);
            ruleControl();

            state._fsp--;

             after(grammarAccess.getPanelAccess().getControlsControlParserRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__ControlsAssignment_4_0"


    // $ANTLR start "rule__Panel__PanelsAssignment_4_1"
    // InternalGuiPro.g:1682:1: rule__Panel__PanelsAssignment_4_1 : ( rulePanel ) ;
    public final void rule__Panel__PanelsAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1686:1: ( ( rulePanel ) )
            // InternalGuiPro.g:1687:2: ( rulePanel )
            {
            // InternalGuiPro.g:1687:2: ( rulePanel )
            // InternalGuiPro.g:1688:3: rulePanel
            {
             before(grammarAccess.getPanelAccess().getPanelsPanelParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            rulePanel();

            state._fsp--;

             after(grammarAccess.getPanelAccess().getPanelsPanelParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panel__PanelsAssignment_4_1"


    // $ANTLR start "rule__Button__NameAssignment_1"
    // InternalGuiPro.g:1697:1: rule__Button__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Button__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1701:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1702:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1702:2: ( RULE_ID )
            // InternalGuiPro.g:1703:3: RULE_ID
            {
             before(grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__NameAssignment_1"


    // $ANTLR start "rule__Button__CenterAssignment_2"
    // InternalGuiPro.g:1712:1: rule__Button__CenterAssignment_2 : ( ruleText ) ;
    public final void rule__Button__CenterAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1716:1: ( ( ruleText ) )
            // InternalGuiPro.g:1717:2: ( ruleText )
            {
            // InternalGuiPro.g:1717:2: ( ruleText )
            // InternalGuiPro.g:1718:3: ruleText
            {
             before(grammarAccess.getButtonAccess().getCenterTextParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleText();

            state._fsp--;

             after(grammarAccess.getButtonAccess().getCenterTextParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__CenterAssignment_2"


    // $ANTLR start "rule__Button__RightAssignment_3"
    // InternalGuiPro.g:1727:1: rule__Button__RightAssignment_3 : ( ruleSize ) ;
    public final void rule__Button__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1731:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1732:2: ( ruleSize )
            {
            // InternalGuiPro.g:1732:2: ( ruleSize )
            // InternalGuiPro.g:1733:3: ruleSize
            {
             before(grammarAccess.getButtonAccess().getRightSizeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getButtonAccess().getRightSizeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__RightAssignment_3"


    // $ANTLR start "rule__TextField__NameAssignment_1"
    // InternalGuiPro.g:1742:1: rule__TextField__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__TextField__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1746:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1747:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1747:2: ( RULE_ID )
            // InternalGuiPro.g:1748:3: RULE_ID
            {
             before(grammarAccess.getTextFieldAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTextFieldAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__NameAssignment_1"


    // $ANTLR start "rule__TextField__CenterAssignment_2"
    // InternalGuiPro.g:1757:1: rule__TextField__CenterAssignment_2 : ( ruleText ) ;
    public final void rule__TextField__CenterAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1761:1: ( ( ruleText ) )
            // InternalGuiPro.g:1762:2: ( ruleText )
            {
            // InternalGuiPro.g:1762:2: ( ruleText )
            // InternalGuiPro.g:1763:3: ruleText
            {
             before(grammarAccess.getTextFieldAccess().getCenterTextParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleText();

            state._fsp--;

             after(grammarAccess.getTextFieldAccess().getCenterTextParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__CenterAssignment_2"


    // $ANTLR start "rule__TextField__RightAssignment_3"
    // InternalGuiPro.g:1772:1: rule__TextField__RightAssignment_3 : ( ruleSize ) ;
    public final void rule__TextField__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1776:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1777:2: ( ruleSize )
            {
            // InternalGuiPro.g:1777:2: ( ruleSize )
            // InternalGuiPro.g:1778:3: ruleSize
            {
             before(grammarAccess.getTextFieldAccess().getRightSizeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getTextFieldAccess().getRightSizeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TextField__RightAssignment_3"


    // $ANTLR start "rule__CheckBox__NameAssignment_1"
    // InternalGuiPro.g:1787:1: rule__CheckBox__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__CheckBox__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1791:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1792:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1792:2: ( RULE_ID )
            // InternalGuiPro.g:1793:3: RULE_ID
            {
             before(grammarAccess.getCheckBoxAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getCheckBoxAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__NameAssignment_1"


    // $ANTLR start "rule__CheckBox__CenterAssignment_2"
    // InternalGuiPro.g:1802:1: rule__CheckBox__CenterAssignment_2 : ( ruleText ) ;
    public final void rule__CheckBox__CenterAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1806:1: ( ( ruleText ) )
            // InternalGuiPro.g:1807:2: ( ruleText )
            {
            // InternalGuiPro.g:1807:2: ( ruleText )
            // InternalGuiPro.g:1808:3: ruleText
            {
             before(grammarAccess.getCheckBoxAccess().getCenterTextParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleText();

            state._fsp--;

             after(grammarAccess.getCheckBoxAccess().getCenterTextParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__CenterAssignment_2"


    // $ANTLR start "rule__CheckBox__RightAssignment_3"
    // InternalGuiPro.g:1817:1: rule__CheckBox__RightAssignment_3 : ( ruleSize ) ;
    public final void rule__CheckBox__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1821:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1822:2: ( ruleSize )
            {
            // InternalGuiPro.g:1822:2: ( ruleSize )
            // InternalGuiPro.g:1823:3: ruleSize
            {
             before(grammarAccess.getCheckBoxAccess().getRightSizeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getCheckBoxAccess().getRightSizeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CheckBox__RightAssignment_3"


    // $ANTLR start "rule__Label__NameAssignment_1"
    // InternalGuiPro.g:1832:1: rule__Label__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Label__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1836:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1837:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1837:2: ( RULE_ID )
            // InternalGuiPro.g:1838:3: RULE_ID
            {
             before(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__NameAssignment_1"


    // $ANTLR start "rule__Label__CenterAssignment_2"
    // InternalGuiPro.g:1847:1: rule__Label__CenterAssignment_2 : ( ruleText ) ;
    public final void rule__Label__CenterAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1851:1: ( ( ruleText ) )
            // InternalGuiPro.g:1852:2: ( ruleText )
            {
            // InternalGuiPro.g:1852:2: ( ruleText )
            // InternalGuiPro.g:1853:3: ruleText
            {
             before(grammarAccess.getLabelAccess().getCenterTextParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleText();

            state._fsp--;

             after(grammarAccess.getLabelAccess().getCenterTextParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__CenterAssignment_2"


    // $ANTLR start "rule__Label__RightAssignment_3"
    // InternalGuiPro.g:1862:1: rule__Label__RightAssignment_3 : ( ruleSize ) ;
    public final void rule__Label__RightAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1866:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1867:2: ( ruleSize )
            {
            // InternalGuiPro.g:1867:2: ( ruleSize )
            // InternalGuiPro.g:1868:3: ruleSize
            {
             before(grammarAccess.getLabelAccess().getRightSizeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getLabelAccess().getRightSizeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__RightAssignment_3"


    // $ANTLR start "rule__ListView__NameAssignment_1"
    // InternalGuiPro.g:1877:1: rule__ListView__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__ListView__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1881:1: ( ( RULE_ID ) )
            // InternalGuiPro.g:1882:2: ( RULE_ID )
            {
            // InternalGuiPro.g:1882:2: ( RULE_ID )
            // InternalGuiPro.g:1883:3: RULE_ID
            {
             before(grammarAccess.getListViewAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getListViewAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__NameAssignment_1"


    // $ANTLR start "rule__ListView__RightAssignment_2"
    // InternalGuiPro.g:1892:1: rule__ListView__RightAssignment_2 : ( ruleSize ) ;
    public final void rule__ListView__RightAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1896:1: ( ( ruleSize ) )
            // InternalGuiPro.g:1897:2: ( ruleSize )
            {
            // InternalGuiPro.g:1897:2: ( ruleSize )
            // InternalGuiPro.g:1898:3: ruleSize
            {
             before(grammarAccess.getListViewAccess().getRightSizeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getListViewAccess().getRightSizeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListView__RightAssignment_2"


    // $ANTLR start "rule__Size__XAssignment_1"
    // InternalGuiPro.g:1907:1: rule__Size__XAssignment_1 : ( ruleNumber ) ;
    public final void rule__Size__XAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1911:1: ( ( ruleNumber ) )
            // InternalGuiPro.g:1912:2: ( ruleNumber )
            {
            // InternalGuiPro.g:1912:2: ( ruleNumber )
            // InternalGuiPro.g:1913:3: ruleNumber
            {
             before(grammarAccess.getSizeAccess().getXNumberParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleNumber();

            state._fsp--;

             after(grammarAccess.getSizeAccess().getXNumberParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__XAssignment_1"


    // $ANTLR start "rule__Size__YAssignment_3"
    // InternalGuiPro.g:1922:1: rule__Size__YAssignment_3 : ( ruleNumber ) ;
    public final void rule__Size__YAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1926:1: ( ( ruleNumber ) )
            // InternalGuiPro.g:1927:2: ( ruleNumber )
            {
            // InternalGuiPro.g:1927:2: ( ruleNumber )
            // InternalGuiPro.g:1928:3: ruleNumber
            {
             before(grammarAccess.getSizeAccess().getYNumberParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleNumber();

            state._fsp--;

             after(grammarAccess.getSizeAccess().getYNumberParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__YAssignment_3"


    // $ANTLR start "rule__Text__ValueAssignment_1"
    // InternalGuiPro.g:1937:1: rule__Text__ValueAssignment_1 : ( ruleInput ) ;
    public final void rule__Text__ValueAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGuiPro.g:1941:1: ( ( ruleInput ) )
            // InternalGuiPro.g:1942:2: ( ruleInput )
            {
            // InternalGuiPro.g:1942:2: ( ruleInput )
            // InternalGuiPro.g:1943:3: ruleInput
            {
             before(grammarAccess.getTextAccess().getValueInputParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleInput();

            state._fsp--;

             after(grammarAccess.getTextAccess().getValueInputParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Text__ValueAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000002408000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000016000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000006002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000408000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000003F6000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00000000003E6002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000002400000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000020L});

}